# Claude Code Guardrails & Workflow Pack

A drop-in safety and workflow layer for [Claude Code](https://docs.anthropic.com/en/docs/claude-code).
Two `PreToolUse` hooks stop the agent from running destructive shell commands or
writing secrets into your repo; a changelog skill, a PR-review subagent and a
production-grade `CLAUDE.md` template round out the day-to-day workflow.

- **Zero dependencies.** Python 3.8+ standard library and bash. No pip, no npm.
- **Blocks, does not nag.** Exit code 2 with a precise reason; Claude sees why and adapts.
- **Understands shells.** Quoting, `&&`/`||`/`;`/`|`, subshells, `$(...)`, heredocs,
  `sudo -E`, `env X=1`, `nohup`, `timeout`, `xargs`, `npx`, `bash -c "..."`, `eval`.
- **Configurable.** Allow-lists, extra block patterns, protected branches, rule toggles.
- **Tested.** 400+ assertions covering blocked and allowed commands, secrets, the
  changelog generator against real git repos, and the installer.

```
claude-code-guardrails/
├── hooks/
│   ├── guard-destructive.py       PreToolUse hook for Bash
│   └── guard-secrets.py           PreToolUse hook for Edit/Write/MultiEdit/NotebookEdit
├── skills/changelog/
│   ├── SKILL.md                   /changelog skill instructions
│   └── scripts/changelog.py       Keep-a-Changelog generator
├── agents/pr-reviewer.md          structured PR review subagent
├── templates/CLAUDE.md.nextjs-sqlite
├── guardrails.example.json        annotated configuration
├── install.sh                     idempotent installer / uninstaller
├── tests/                         python3 -m unittest discover -s tests -v
└── README.md
```

## Install

```bash
# Into one project (creates/merges <project>/.claude/...)
./install.sh /path/to/project

# Into every project for your user (~/.claude)
./install.sh --global

# Options
./install.sh /path/to/project --dry-run      # show what would change
./install.sh /path/to/project --no-config    # skip .claude/guardrails.json
./install.sh /path/to/project --no-template  # skip the CLAUDE.md template copy
./install.sh /path/to/project --force        # overwrite an existing guardrails.json
./install.sh /path/to/project --uninstall    # remove files and hook entries
```

The installer copies the hooks, skill and agent into `.claude/`, writes a starter
`.claude/guardrails.json` if none exists, and merges these entries into
`.claude/settings.json` (existing hooks and settings are preserved; a
`settings.json.bak` is written before any change):

```json
{
  "hooks": {
    "PreToolUse": [
      { "matcher": "Bash",
        "hooks": [{ "type": "command", "command": "python3 \"$CLAUDE_PROJECT_DIR\"/.claude/hooks/guard-destructive.py" }] },
      { "matcher": "Edit|Write|MultiEdit|NotebookEdit",
        "hooks": [{ "type": "command", "command": "python3 \"$CLAUDE_PROJECT_DIR\"/.claude/hooks/guard-secrets.py" }] }
    ]
  }
}
```

Restart Claude Code (or run `/hooks`) after installing. Verify:

```bash
echo '{"tool_name":"Bash","tool_input":{"command":"rm -rf /"}}' \
  | python3 .claude/hooks/guard-destructive.py; echo "exit=$?"
# BLOCKED by guard-destructive (rule: rm_recursive_protected) ... exit=2
```

Manual install: copy `hooks/`, `skills/`, `agents/` into `.claude/` and add the
JSON above to `.claude/settings.json` yourself.

## What it blocks

### guard-destructive.py (Bash tool)

| Category | Examples blocked | Rule id(s) |
|---|---|---|
| Recursive delete of critical paths | `rm -rf /`, `rm -rf ~`, `rm -rf $HOME/`, `rm -rf /etc/nginx`, `rm -rf /usr/local`, `rm -rf ~/Documents`, `rm -rf .`, `rm -rf ..`, `rm -rf .git`, `rm -rf ../..` (when it resolves to home) | `rm_recursive_protected`, `rm_no_preserve_root` |
| Bare wildcards | `rm -rf *`, `rm -rf ./*`, `rm -rf ~/*`, `rm *`, `rm -f .*` | `rm_wildcard` |
| Empty-variable footguns | `rm -rf $DIR/`, `rm -rf ${OUT}/*` | `rm_variable_prefix` |
| Elevated deletes | `sudo rm ...`, `sudo -E rm ...`, `doas rm ...` | `sudo_rm` |
| Deleting protected files | `rm .env`, `rm dev.db`, `rm ~/.ssh/id_rsa`, `shred ~/.bashrc`, `rm server.pem` | `protected_file_delete`, `db_file_delete` |
| Truncating protected files | `> .env`, `echo x > ~/.zshrc`, `truncate -s 0 .env`, `tee .env`, `cp /dev/null .env`, `: > app.db` (`>>` append is allowed) | `protected_file_truncate` |
| Force pushes to protected branches | `git push --force origin main`, `git push -f origin HEAD:master`, `git push origin +main`, `--force-with-lease` (configurable), `--mirror`, `--force --all`, `git push -f` with no refspec on a protected or unknown branch | `git_force_push_protected`, `git_force_push_unknown_branch` |
| Deleting protected branches | `git push origin --delete main`, `git push origin :main`, `git branch -D main` | `git_delete_protected_branch` |
| Discarding local work | `git reset --hard`, `git clean -f[dx]` (dry-run `-n` allowed), `git checkout -- .`, `git checkout -f`, `git restore .`, `git stash clear/drop` | `git_reset_hard`, `git_clean_force`, `git_discard_worktree`, `git_stash_destroy` |
| History destruction | `git filter-branch`, `git filter-repo`, `git reflog expire --expire=now`, `git gc --prune=now` | `git_history_rewrite` |
| Destructive SQL to a DB client | `psql -c "DROP TABLE users"`, `sqlite3 app.db "DROP TABLE ..."`, `TRUNCATE`, `DELETE FROM t` (no WHERE), heredocs piped into `psql`/`mysql`. `echo`/`grep`/`git commit -m` mentioning SQL are fine. | `sql_drop`, `sql_truncate`, `sql_delete_without_where` |
| Database resets | `dropdb`, `mysqladmin drop`, `redis-cli flushall`, `mongosh dropDatabase()`, `prisma migrate reset`, `prisma db push --force-reset`, `rails db:drop`, `artisan migrate:fresh`, `manage.py flush`, `supabase db reset`, `wrangler d1 delete`, `heroku pg:reset` | `db_destroy` |
| Cloud / infra teardown | `terraform destroy`, `pulumi destroy`, `aws s3 rb`, `aws s3 rm --recursive`, `aws rds delete-*`, `gcloud ... delete`, `az ... delete`, `kubectl delete namespace`/`--all`, `docker compose down -v`, `docker system prune`, `vercel remove`, `fly apps destroy` | `cloud_destroy`, `container_volume_destroy` |
| Permissions | `chmod -R 777 ...`, `chmod -R a+w`, `chmod -R 000`, `chmod 777 /`, `chown -R user /` or `~` | `chmod_world_writable`, `chmod_protected`, `chown_recursive_protected` |
| Disks and devices | `dd of=/dev/sda`, `> /dev/sda`, `mkfs.*`, `fdisk /dev/sda` (`-l` allowed), `wipefs`, `parted`, `diskutil eraseDisk` | `dd_device`, `write_block_device`, `disk_format` |
| Remote code execution | `curl ... \| sh`, `wget -qO- ... \| sudo bash`, `curl ... \| python3`, `sh <(curl ...)`, `bash -c "$(curl ...)"`, `eval "$(curl ...)"`. `curl \| jq`, `curl \| python3 -m json.tool` are fine. | `pipe_to_shell` |
| Fork bombs | `:(){ :\|:& };:` and named variants | `fork_bomb` |
| System | `shutdown`, `reboot`, `halt`, `systemctl poweroff`, `init 0`, `kill -9 -1`, `crontab -r`, `history -c`, `iptables -F` | `system_power`, `kill_all_processes`, `crontab_remove`, `history_clear`, `firewall_flush` |
| Moving protected trees | `mv / ...`, `mv ~ ...`, `mv /etc ...` | `mv_protected` |
| `find` deletes | `find / -delete`, `find ~ -exec rm ...`, `find . -delete` with no filter (`find . -name '*.pyc' -delete` is fine) | `find_delete_protected`, `find_delete_unfiltered` |
| Your own patterns | anything matching `block_patterns` | `block_pattern` |

All of the above are also detected inside `bash -c '...'`, `sh -c`, `su -c`,
`eval`, `$(...)`, backticks, `( ... )`, `{ ...; }`, `if/for/while` bodies,
`find -exec`, and after wrapper prefixes (`sudo`, `env`, `nohup`, `nice`,
`time`, `timeout`, `xargs`, `npx`, `pnpm dlx`, `poetry run`, `bundle exec`, ...).

Out of scope by design: commands run on other machines (`ssh host 'rm -rf /'`),
inside containers (`docker run img rm -rf /`), or inside other interpreters
(`python -c "shutil.rmtree('/')"`). Opaque scripts (`npm run nuke`) cannot be inspected.

### guard-secrets.py (Edit / Write / MultiEdit / NotebookEdit)

Blocks writing credential-looking values into files that are tracked by git or
would be committed. Detected formats (rule ids):

`aws_access_key` (AKIA/ASIA...), `aws_secret_key`, `private_key` (RSA/EC/DSA/OpenSSH/PGP blocks),
`anthropic_api_key` (sk-ant-...), `openai_api_key` (sk-..., sk-proj-...), `stripe_secret_key` (sk_live/sk_test/rk_live),
`github_token` (ghp_/gho_/ghu_/ghs_/ghr_/github_pat_), `gitlab_token`, `slack_token`, `slack_webhook`,
`google_api_key` (AIza...), `google_oauth_secret`, `sendgrid_api_key`, `twilio_api_key`, `npm_token`,
`pypi_token`, `huggingface_token`, `digitalocean_token`, `shopify_token`, `mailgun_key`,
`telegram_bot_token`, `discord_bot_token`, `linear_api_key`, `notion_token`, `resend_api_key`,
`planetscale_token`, `age_secret_key`, `jwt`, `connection_string_password`
(`postgres://user:REALPASS@prod-host/db`; localhost and placeholder passwords are ignored),
`generic_assignment` (`password = "..."`, `api_key: '...'` etc. with a high-entropy value of 16+ chars).

Which files are scanned:

| File | Scanned? |
|---|---|
| Tracked by git (even `.env` if someone committed it) | Yes |
| Untracked and matched by `.gitignore` | No |
| Untracked and matching `allow_files` (`.env`, `.env.local`, `*.local`, `.npmrc`, ...) | No |
| `.env.example`, `*.sample`, `*.template`, `*.dist`, docs (`.md`, `.txt`) | Yes (templates get committed) |
| Anything else, including files outside a git repo | Yes |

False-positive controls: documented fake keys (`AKIAIOSFODNN7EXAMPLE`), values containing
`EXAMPLE`, `XXXX`, `changeme`, `<...>`, `${...}`, `{{...}}`, `process.env`, low-entropy or
repeated characters are ignored; append `# guardrails-allow-secret` to a line to skip it;
add regexes to `allow_patterns`; disable rules with `disabled_rules`. The block message
shows the rule, line number and a masked value (`AKIA...NB3`) -- never the full secret.

## Configuration

`.claude/guardrails.json` in the project (highest priority) and/or
`~/.claude/guardrails.json` (user-wide). Lists are merged, scalars in the project
file win. `GUARDRAILS_CONFIG=/path/file.json` adds one more file. Keys or list
entries starting with `_` are comments. See `guardrails.example.json`.

```json
{
  "destructive": {
    "protected_branches": ["main", "master", "develop", "production", "prod", "staging", "release", "release/*"],
    "protected_paths": ["~/work/important-data"],
    "protected_files": ["config/production.yml"],
    "allow_patterns": ["^rm -rf \\./?\\.next/?$"],
    "block_patterns": ["^npm publish"],
    "disabled_rules": ["db_file_delete"],
    "allow_force_with_lease": false,
    "block_direct_push_to_protected": false,
    "fail_closed": false
  },
  "secrets": {
    "allow_files": ["fixtures/*.json"],
    "allow_patterns": ["^sk-test-"],
    "placeholder_words": ["acme-demo"],
    "disabled_rules": ["jwt"],
    "respect_gitignore": true,
    "scan_outside_git": true,
    "generic_min_entropy": 3.5,
    "generic_min_length": 16,
    "fail_closed": false
  }
}
```

| Key | Meaning |
|---|---|
| `allow_patterns` (destructive) | Regex (`re.search`) against the full command. Match = always allowed. Use anchors. |
| `block_patterns` | Regex against the full command. Match = always blocked (`block_pattern`). |
| `protected_branches` | Branch names or fnmatch globs for the git rules. |
| `protected_paths` | Extra directories `rm -r`, `mv`, `chmod -R`, `find -delete` may not touch. `~` and relative paths work. |
| `protected_files` | Extra globs that may not be deleted/truncated. |
| `disabled_rules` | Rule ids from the tables above. |
| `allow_force_with_lease` | Treat `--force-with-lease` to protected branches as safe. |
| `block_direct_push_to_protected` | Also block plain `git push origin main` (PR-only workflows). |
| `fail_closed` | Block when the hook input cannot be parsed or the hook crashes (default: allow + warning). |
| `allow_patterns` (secrets) | Regex against the *detected value*. |
| `allow_files` | Globs of untracked files allowed to hold secrets. |
| `placeholder_words` | Extra substrings that mark a value as fake. |
| `respect_gitignore` / `scan_outside_git` | See table above. |

Rule ids appear in every block message, so tuning is a copy-paste away.

## The block message Claude sees

```
BLOCKED by guard-destructive (rule: git_force_push_protected)
  reason : force-pushing to protected branch `main`
  command: git push --force origin main
  This command was not executed. If it is genuinely required, ask the user to run it
  manually, or add a regex to "allow_patterns" (or the rule id to "disabled_rules")
  under "destructive" in .claude/guardrails.json.
```

Claude reads this, explains the situation to you, and proposes a safer route
(`--force-with-lease` on a feature branch, `git stash` instead of `reset --hard`, and so on).

## Changelog skill

Installed as `.claude/skills/changelog/`. Ask Claude "update the changelog for 1.4.0"
or run the script directly:

```bash
python3 .claude/skills/changelog/scripts/changelog.py                 # preview since last tag
python3 .claude/skills/changelog/scripts/changelog.py --version 1.4.0 --write
python3 .claude/skills/changelog/scripts/changelog.py --since v1.2.0 --include-all --format json
```

Conventional commits are grouped into Keep-a-Changelog sections (Breaking Changes,
Added, Changed, Deprecated, Removed, Fixed, Security, Performance, Documentation,
Reverted; `chore/ci/build/test` only with `--include-all`). Commit hashes link to
GitHub/GitLab/Bitbucket automatically; issue refs (`#42`) are appended; `--write`
inserts or replaces the version section in `CHANGELOG.md` and is safe to re-run.

## PR reviewer agent

Installed as `.claude/agents/pr-reviewer.md`. Invoke with "use the pr-reviewer agent
on PR 123" or "review this branch". It gathers the diff (`gh pr diff`, or
`git diff <merge-base>...HEAD`), reads surrounding code as needed, and returns:

- Summary and **risk level** (Low / Medium / High / Critical) with justification
- **Findings table**: severity, confidence, `file:line`, what breaks, suggested fix
- **Test gaps** and questions for the author
- A ready-to-use **conventional commit message**

It is read-only (tools: Bash, Read, Grep, Glob) and never posts to GitHub.

## CLAUDE.md template

`templates/CLAUDE.md.nextjs-sqlite` is an opinionated project brief for a
Next.js App Router + SQLite (better-sqlite3 / Drizzle) SaaS: stack table, commands,
layout, architecture rules (server actions, tenant scoping, integer money),
SQLite-specific migration guidance, auth/security rules, conventions, git workflow
and a "when unsure" section that tells Claude to stop before irreversible steps.
The installer drops it at `<project>/CLAUDE.md.nextjs-sqlite.template`; rename to
`CLAUDE.md`, fill in the `<placeholders>`, delete what does not apply.

## Running the tests

```bash
python3 -m unittest discover -s tests -v
```

The suite spawns the real hook processes with a sandboxed `HOME`, creates
temporary git repositories for the branch-resolution, secrets and changelog
tests, and runs `install.sh` end to end (including `--global` against a temp
home). Requires `git` on PATH.

## Requirements and compatibility

- Python 3.8 or newer on PATH as `python3` (macOS and Linux; Windows via WSL or Git Bash).
- git (for branch resolution, gitignore checks, and the changelog script). The hooks
  degrade gracefully without it.
- Claude Code with hooks support (`PreToolUse`, exit-code-2 blocking).
- Hooks add roughly 30-60 ms per Bash call (one Python start-up).

## FAQ

**Claude keeps hitting a rule on something I do routinely.**
Add an anchored regex to `allow_patterns` or the rule id to `disabled_rules`; the
block message names both. Prefer a narrow allow pattern over disabling a rule.

**Can Claude bypass the hook?**
Hooks run in Claude Code's process, outside the shell Claude controls. Editing
`.claude/settings.json` or the hook files is possible but visible in your diff;
put `settings.json` under review or use `--global` install if that concerns you.

**Does guard-secrets read my whole repo?**
No. It only inspects the text about to be written and asks git whether the target
file is tracked/ignored. Nothing is uploaded anywhere.

**Windows?**
Native PowerShell is not supported; the hooks work under WSL and Git Bash where
`python3` and `git` are available.

## License

Commercial license, see `LICENSE.txt`.
