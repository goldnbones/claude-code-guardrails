# Changelog

All notable changes to this pack are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [1.0.0] - 2026-09-14

### Added

- `hooks/guard-destructive.py`: PreToolUse hook for Bash blocking recursive
  deletes of protected paths, bare wildcards, `sudo rm`, protected-file
  truncation, force pushes and branch deletion on protected branches,
  `git reset --hard` / `clean -f` / `checkout -- .` / `stash clear`, history
  rewrites, destructive SQL to database clients, database and infra resets,
  world-writable `chmod -R`, raw device writes, disk formatting, fork bombs,
  `curl | sh` piping, power/kill/crontab commands and user-defined patterns.
  Shell-aware parsing (quotes, chains, subshells, substitutions, heredocs,
  wrappers such as `sudo -E`, `env`, `timeout`, `xargs`, `npx`, `bash -c`).
- `hooks/guard-secrets.py`: PreToolUse hook for Edit/Write/MultiEdit/NotebookEdit
  detecting 30 credential formats plus connection-string passwords and
  entropy-based generic assignments; git-aware (tracked files always scanned,
  ignored files skipped), placeholder detection, inline allow marker.
- `skills/changelog`: Keep-a-Changelog generator from conventional commits with
  idempotent `--write`, JSON output, commit links and tag patterns.
- `agents/pr-reviewer.md`: structured, read-only PR review subagent.
- `templates/CLAUDE.md.nextjs-sqlite`: CLAUDE.md template for Next.js + SQLite SaaS.
- `install.sh`: idempotent installer/uninstaller with settings.json merge,
  `--global`, `--dry-run`, `--force`.
- Test-suite: 400+ assertions across hooks, changelog and installer.
