"""Tests for hooks/guard-secrets.py."""

import os
import subprocess
import unittest

from helpers import SECRETS_HOOK, Sandbox, run_hook, init_repo, git

BLOCK, ALLOW = True, False

# Synthetic credentials; none of these are real.
AWS_KEY = "AKIA" + "JQ7XK2M9PZ4L8NB3"
JWT = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
       "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0."
       "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c")

CONTENT_CASES = [
    # (label, content, expect_block)
    ("aws access key", 'const k = "%s";' % AWS_KEY, BLOCK),
    ("aws documented example key", 'const k = "AKIAIOSFODNN7EXAMPLE";', ALLOW),
    ("aws secret key", 'aws_secret_access_key = "kR9tLm2XpQ7vB4nC8wE1yU5iO3aS6dF0gH2jK4lZ"', BLOCK),
    ("aws secret example", 'aws_secret_access_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"', ALLOW),
    ("rsa private key", "-----BEGIN RSA PRIVATE KEY-----\nMIIEow...\n-----END RSA PRIVATE KEY-----", BLOCK),
    ("openssh private key", "-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXkt", BLOCK),
    ("ec private key", "-----BEGIN EC PRIVATE KEY-----", BLOCK),
    ("pgp private key", "-----BEGIN PGP PRIVATE KEY BLOCK-----", BLOCK),
    ("public key is fine", "-----BEGIN PUBLIC KEY-----\nMIIBIjANBg", ALLOW),
    ("certificate is fine", "-----BEGIN CERTIFICATE-----\nMIID", ALLOW),
    ("anthropic key", "ANTHROPIC_API_KEY=sk-ant-api03-Qx7Lm2Vp9Kz4Rt8Wn3Yb6Hc1Jf5Dg0Se2Ua4Ti7Ok9Pl3", BLOCK),
    ("openai project key", "sk-proj-Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZa7bCd0e", BLOCK),
    ("openai classic key", 'OPENAI_API_KEY="sk-Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZa7bCd0eF"', BLOCK),
    ("openai placeholder xs", "OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", ALLOW),
    ("openai your-key placeholder", "OPENAI_API_KEY=sk-your-api-key-here-1234567890", ALLOW),
    ("sk- in prose is fine", "the task-list is ready", ALLOW),
    ("stripe live secret", "STRIPE_SECRET_KEY=sk_live_4eC39HqLyjWDarjtT1zdp7dc", BLOCK),
    ("stripe restricted key", "rk_live_4eC39HqLyjWDarjtT1zdp7dc", BLOCK),
    ("stripe publishable is public", "NEXT_PUBLIC_STRIPE_KEY=pk_live_4eC39HqLyjWDarjtT1zdp7dc", ALLOW),
    ("github classic pat", "token: ghp_Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZa7b", BLOCK),
    ("github fine-grained pat", "github_pat_11ABCDEFG0abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJ", BLOCK),
    ("github oauth token", "gho_Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZa7b", BLOCK),
    ("gitlab pat", "glpat-Ab3dEf6gHi9jKl2mNo5p", BLOCK),
    ("slack bot token", "xoxb-123456789012-1234567890123-AbCdEfGhIjKlMnOpQrStUvWx", BLOCK),
    ("slack webhook", "https://hooks.slack.com/services/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7", BLOCK),
    ("google api key", "AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY", BLOCK),
    ("google oauth secret", "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", BLOCK),
    ("sendgrid key", "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", BLOCK),
    ("npm token", "//registry.npmjs.org/:_authToken=npm_Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZa7bC", BLOCK),
    ("huggingface token", "HF_TOKEN=hf_Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZ", BLOCK),
    ("digitalocean token", "dop_v1_" + "a1b2c3d4" * 8, BLOCK),
    ("telegram bot token", "BOT_TOKEN=123456789:AAEx7Lm2Vp9Kz4Rt8Wn3Yb6Hc1Jf5Dg0Se2U", BLOCK),
    ("jwt", "Authorization: Bearer " + JWT, BLOCK),
    ("connection string with real password", "DATABASE_URL=postgres://app:Xk9mP2vL7qR4tW8n@db.example.com:5432/app", BLOCK),
    ("mongodb srv with password", "mongodb+srv://admin:Xk9mP2vL7qR4tW8n@cluster0.abcde.mongodb.net/db", BLOCK),
    ("connection string localhost", "DATABASE_URL=postgres://postgres:postgres@localhost:5432/app", ALLOW),
    ("connection string docker host", "redis://default:supersecret123@redis:6379", ALLOW),
    ("connection string placeholder", "DATABASE_URL=postgres://user:password@host:5432/db", ALLOW),
    ("connection string env interpolation", "DATABASE_URL=postgres://user:${DB_PASSWORD}@host:5432/db", ALLOW),
    ("connection string no password", "DATABASE_URL=postgres://host:5432/db", ALLOW),
    ("generic high-entropy secret", 'const apiKey = "aB3$dE9fGh2!kLm7nOp4QrS8tUv";', BLOCK),
    ("generic password yaml", "password: 'Tq8#vL2mZp9!xK4rWn7e'", BLOCK),
    ("generic client_secret json", '{"client_secret": "Zx4Qw9Er7Ty2Ui8Op1As6Df3Gh5Jk0Lp"}', BLOCK),
    ("generic env reference", "const apiKey = process.env.API_KEY;", ALLOW),
    ("generic os.environ", 'SECRET_KEY = os.environ["SECRET_KEY"]', ALLOW),
    ("generic placeholder", 'password = "changeme-please-now"', ALLOW),
    ("generic low entropy", 'password = "aaaaaaaaaaaaaaaaaaaa"', ALLOW),
    ("generic short value", 'token = "abc123"', ALLOW),
    ("generic key name field", 'apiKeyName = "MyProductionApiKeyV2Name"', ALLOW),
    ("generic sentence", 'const tokenHint = "Paste your token from the dashboard";', ALLOW),
    ("generic path", 'secretPath = "/var/run/secrets/kubernetes.io/serviceaccount"', ALLOW),
    ("generic template var", 'api_key = "{{ vault_api_key }}"', ALLOW),
    ("generic angle placeholder", 'api_key = "<your-api-key-goes-here>"', ALLOW),
    ("inline allow marker", 'const k = "%s"; // guardrails-allow-secret' % AWS_KEY, ALLOW),
    ("plain code", "export function add(a: number, b: number) { return a + b }", ALLOW),
    ("sha256 hash is not a secret", 'integrity = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"', ALLOW),
    ("uuid is not a secret", 'id = "550e8400-e29b-41d4-a716-446655440000"', ALLOW),
    ("markdown docs mentioning keys", "Set `OPENAI_API_KEY` in your environment before running.", ALLOW),
    ("empty content", "", ALLOW),
]


class SecretsGuardTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.sb = Sandbox()
        cls.repo = init_repo(os.path.join(cls.sb.home, "code", "repo"))
        with open(os.path.join(cls.repo, ".gitignore"), "w") as fh:
            fh.write(".env\n.env.local\n.env.*.local\nsecrets/\n*.local\n")
        with open(os.path.join(cls.repo, "tracked.ts"), "w") as fh:
            fh.write("export const x = 1;\n")
        os.makedirs(os.path.join(cls.repo, "secrets"), exist_ok=True)
        git(cls.repo, "add", "-A")
        git(cls.repo, "commit", "-q", "-m", "init")
        cls.env = cls.sb.env(CLAUDE_PROJECT_DIR=cls.repo)

    @classmethod
    def tearDownClass(cls):
        cls.sb.cleanup()

    def payload(self, content, tool="Write", path="src/config.ts", repo=None):
        repo = repo or self.repo
        file_path = os.path.join(repo, path) if path else None
        if tool == "Write":
            ti = {"file_path": file_path, "content": content}
        elif tool == "Edit":
            ti = {"file_path": file_path, "old_string": "old", "new_string": content}
        elif tool == "MultiEdit":
            ti = {"file_path": file_path, "edits": [{"old_string": "a", "new_string": "safe"},
                                                    {"old_string": "b", "new_string": content}]}
        elif tool == "NotebookEdit":
            ti = {"notebook_path": file_path, "new_source": content}
        else:
            ti = {"file_path": file_path}
        if file_path is None:
            ti.pop("file_path", None)
        return {"session_id": "t", "tool_name": tool, "tool_input": ti, "cwd": repo}

    def run_case(self, content, **kw):
        env = kw.pop("env", self.env)
        return run_hook(SECRETS_HOOK, self.payload(content, **kw), env)

    def assert_block(self, content, rule=None, **kw):
        res = self.run_case(content, **kw)
        self.assertEqual(res.returncode, 2, "expected BLOCK for %r\nstderr: %s" % (content, res.stderr))
        self.assertIn("BLOCKED by guard-secrets", res.stderr)
        if rule:
            self.assertIn("rule: %s" % rule, res.stderr)
        return res

    def assert_allow(self, content, **kw):
        res = self.run_case(content, **kw)
        self.assertEqual(res.returncode, 0, "expected ALLOW for %r\nstderr: %s" % (content, res.stderr))
        self.assertNotIn("warning", res.stderr)
        return res

    # ---- content table --------------------------------------------------------
    def test_content_table(self):
        for label, content, expect_block in CONTENT_CASES:
            with self.subTest(label=label):
                if expect_block:
                    self.assert_block(content)
                else:
                    self.assert_allow(content)

    def test_rule_ids_and_masking(self):
        res = self.assert_block('const k = "%s";' % AWS_KEY, rule="aws_access_key")
        self.assertIn("line 1", res.stderr)
        self.assertIn("AKIA...", res.stderr)
        self.assertNotIn(AWS_KEY, res.stderr, "full secret must never be echoed back")
        self.assert_block("-----BEGIN RSA PRIVATE KEY-----", rule="private_key")
        self.assert_block("sk-ant-api03-Qx7Lm2Vp9Kz4Rt8Wn3Yb6Hc1Jf5Dg0Se2Ua4Ti7Ok9Pl3", rule="anthropic_api_key")
        self.assert_block("ghp_Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZa7b", rule="github_token")
        self.assert_block("postgres://app:Xk9mP2vL7qR4tW8n@db.example.com/app", rule="connection_string_password")
        self.assert_block('apiKey = "aB3$dE9fGh2!kLm7nOp4QrS8tUv"', rule="generic_assignment")

    def test_line_numbers_are_reported(self):
        content = "line one\nline two\nconst k = '%s';\n" % AWS_KEY
        res = self.assert_block(content)
        self.assertIn("line 3", res.stderr)

    def test_multiple_findings_listed(self):
        content = "a = '%s'\nb = 'ghp_Ab3dEf6gHi9jKl2mNo5pQr8sTu1vWx4yZa7b'\n" % AWS_KEY
        res = self.assert_block(content)
        self.assertIn("aws_access_key", res.stderr)
        self.assertIn("github_token", res.stderr)

    # ---- tools ----------------------------------------------------------------
    def test_all_write_tools_are_covered(self):
        for tool in ("Write", "Edit", "MultiEdit", "NotebookEdit"):
            with self.subTest(tool=tool):
                path = "nb.ipynb" if tool == "NotebookEdit" else "src/x.ts"
                self.assert_block('KEY = "%s"' % AWS_KEY, tool=tool, path=path)
                self.assert_allow('KEY = process.env.KEY', tool=tool, path=path)

    def test_multiedit_scans_every_edit(self):
        payload = self.payload("x", tool="MultiEdit")
        payload["tool_input"]["edits"] = [{"old_string": "a", "new_string": "fine"},
                                          {"old_string": "b", "new_string": "also fine"},
                                          {"old_string": "c", "new_string": "k = '%s'" % AWS_KEY}]
        res = run_hook(SECRETS_HOOK, payload, self.env)
        self.assertEqual(res.returncode, 2)
        self.assertIn("edits[2]", res.stderr)

    def test_non_write_tools_ignored(self):
        for tool in ("Read", "Bash", "Grep"):
            with self.subTest(tool=tool):
                payload = {"tool_name": tool, "tool_input": {"content": AWS_KEY, "command": AWS_KEY}}
                self.assertEqual(run_hook(SECRETS_HOOK, payload, self.env).returncode, 0)

    # ---- file classification -------------------------------------------------
    def test_untracked_ignored_env_files_are_allowed(self):
        for path in (".env", ".env.local", ".env.production", "secrets/prod.json", "config.local"):
            with self.subTest(path=path):
                self.assert_allow("AWS_KEY=%s" % AWS_KEY, path=path)

    def test_env_templates_are_scanned(self):
        # .env.example / .env.sample match allow_files (.env.*) and are NOT
        # git-ignored here, but template suffixes override the allow-list.
        self.assert_block("AWS_KEY=%s" % AWS_KEY, path=".env.example")
        self.assert_block("AWS_KEY=%s" % AWS_KEY, path=".env.sample")
        self.assert_block("AWS_KEY=%s" % AWS_KEY, path=".env.template")
        # ...while a real (untracked, not ignored) .env.production is allowed.
        self.assert_allow("AWS_KEY=%s" % AWS_KEY, path=".env.production")

    def test_tracked_file_is_always_scanned(self):
        self.assert_block('const k = "%s"' % AWS_KEY, path="tracked.ts")

    def test_tracked_env_file_is_still_scanned(self):
        with open(os.path.join(self.repo, ".env.ci"), "w") as fh:
            fh.write("x=1\n")
        git(self.repo, "add", "-f", ".env.ci")
        git(self.repo, "commit", "-q", "-m", "add tracked env")
        self.assert_block("AWS_KEY=%s" % AWS_KEY, path=".env.ci")

    def test_new_untracked_source_file_is_scanned(self):
        self.assert_block('const k = "%s"' % AWS_KEY, path="src/brand-new.ts")

    def test_relative_paths_resolve_against_cwd(self):
        payload = self.payload("AWS_KEY=%s" % AWS_KEY, path=None)
        payload["tool_input"]["file_path"] = ".env"      # relative: git-ignored in repo
        self.assertEqual(run_hook(SECRETS_HOOK, payload, self.env).returncode, 0)
        payload["tool_input"]["file_path"] = "src/new.ts"
        self.assertEqual(run_hook(SECRETS_HOOK, payload, self.env).returncode, 2)

    def test_no_file_path_is_scanned(self):
        self.assert_block('const k = "%s"' % AWS_KEY, path=None)

    def test_outside_git_repo(self):
        outside = os.path.join(self.sb.root, "nogit")
        os.makedirs(outside, exist_ok=True)
        self.assert_block('k = "%s"' % AWS_KEY, path="x.ts", repo=outside)
        self.sb.write_config({"secrets": {"scan_outside_git": False}}, where=outside)
        try:
            self.assert_allow('k = "%s"' % AWS_KEY, path="x.ts", repo=outside, env=self.sb.env(CLAUDE_PROJECT_DIR=outside))
        finally:
            self.sb.remove_config(where=outside)

    # ---- configuration --------------------------------------------------------
    def test_disabled_rules(self):
        self.sb.write_config({"secrets": {"disabled_rules": ["jwt", "generic_assignment"]}}, where=self.repo)
        try:
            self.assert_allow("Bearer " + JWT)
            self.assert_allow('apiKey = "aB3$dE9fGh2!kLm7nOp4QrS8tUv"')
            self.assert_block('k = "%s"' % AWS_KEY)
        finally:
            self.sb.remove_config(where=self.repo)

    def test_allow_patterns_match_value(self):
        self.sb.write_config({"secrets": {"allow_patterns": ["^AKIAJQ7X"]}}, where=self.repo)
        try:
            self.assert_allow('k = "%s"' % AWS_KEY)
            self.assert_block('k = "AKIAZZ7XK2M9PZ4L8NB3"')
        finally:
            self.sb.remove_config(where=self.repo)

    def test_allow_files_config(self):
        self.sb.write_config({"secrets": {"allow_files": ["fixtures/*.json"]}}, where=self.repo)
        try:
            self.assert_allow('{"k": "%s"}' % AWS_KEY, path="fixtures/keys.json")
            self.assert_block('{"k": "%s"}' % AWS_KEY, path="src/keys.json")
        finally:
            self.sb.remove_config(where=self.repo)

    def test_placeholder_words_config(self):
        self.sb.write_config({"secrets": {"placeholder_words": ["acme-demo"]}}, where=self.repo)
        try:
            self.assert_allow('apiKey = "acme-demo-Zx4Qw9Er7Ty2Ui8Op1As6"')
        finally:
            self.sb.remove_config(where=self.repo)

    def test_gitignore_can_be_ignored(self):
        self.sb.write_config({"secrets": {"respect_gitignore": False, "allow_files": []}}, where=self.repo)
        try:
            # .env is git-ignored; with respect_gitignore=false and no allow_files
            # it falls through to "would be committed" and gets scanned. Note the
            # default allow_files list is still merged (lists merge), so use a
            # path that is only protected by .gitignore.
            self.assert_block("AWS_KEY=%s" % AWS_KEY, path="secrets/prod.json")
        finally:
            self.sb.remove_config(where=self.repo)

    # ---- malformed input ------------------------------------------------------
    def test_malformed_input_allowed_by_default(self):
        for payload in ("{bad", "", "[]", '{"tool_name": "Write", "tool_input": "x"}', '{"tool_name": "Write"}'):
            with self.subTest(payload=payload):
                res = run_hook(SECRETS_HOOK, payload, self.env)
                self.assertEqual(res.returncode, 0, res.stderr)

    def test_malformed_input_blocked_when_fail_closed(self):
        self.sb.write_config({"secrets": {"fail_closed": True}}, where=self.repo)
        try:
            self.assertEqual(run_hook(SECRETS_HOOK, "{bad", self.env).returncode, 2)
        finally:
            self.sb.remove_config(where=self.repo)


if __name__ == "__main__":
    unittest.main()
