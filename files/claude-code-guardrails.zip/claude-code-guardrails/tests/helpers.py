"""Shared helpers for the guardrails test-suite."""

import json
import os
import shutil
import subprocess
import sys
import tempfile

PACK_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
HOOKS_DIR = os.path.join(PACK_DIR, "hooks")
DESTRUCTIVE_HOOK = os.path.join(HOOKS_DIR, "guard-destructive.py")
SECRETS_HOOK = os.path.join(HOOKS_DIR, "guard-secrets.py")
CHANGELOG_SCRIPT = os.path.join(PACK_DIR, "skills", "changelog", "scripts", "changelog.py")
INSTALL_SH = os.path.join(PACK_DIR, "install.sh")


class Sandbox(object):
    """Temporary HOME + project directory so real user config never leaks in."""

    def __init__(self):
        self.root = tempfile.mkdtemp(prefix="guardrails-test-")
        self.home = os.path.join(self.root, "home")
        self.project = os.path.join(self.home, "code", "proj")
        os.makedirs(self.project)

    def cleanup(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def env(self, **overrides):
        env = dict(os.environ)
        env.pop("GUARDRAILS_CONFIG", None)
        env["HOME"] = self.home
        env["CLAUDE_PROJECT_DIR"] = self.project
        env.update(overrides)
        return env

    def write_config(self, data, where=None):
        where = where or self.project
        cfg_dir = os.path.join(where, ".claude")
        os.makedirs(cfg_dir, exist_ok=True)
        with open(os.path.join(cfg_dir, "guardrails.json"), "w") as fh:
            json.dump(data, fh)

    def remove_config(self, where=None):
        where = where or self.project
        path = os.path.join(where, ".claude", "guardrails.json")
        if os.path.exists(path):
            os.remove(path)


def run_hook(hook, payload, env, cwd=None):
    """Run a hook with a JSON (or raw string) payload; return CompletedProcess."""
    stdin = payload if isinstance(payload, str) else json.dumps(payload)
    return subprocess.run([sys.executable, hook], input=stdin, capture_output=True,
                          text=True, env=env, cwd=cwd)


def bash_payload(command, cwd):
    return {"session_id": "test", "tool_name": "Bash",
            "tool_input": {"command": command}, "cwd": cwd}


def git(repo, *args):
    return subprocess.run(["git", "-C", repo] + list(args), capture_output=True, text=True, check=True).stdout


def init_repo(path, branch="main"):
    os.makedirs(path, exist_ok=True)
    subprocess.run(["git", "init", "-q", "-b", branch, path], check=True, capture_output=True)
    git(path, "config", "user.email", "test@example.com")
    git(path, "config", "user.name", "Test User")
    git(path, "config", "commit.gpgsign", "false")
    return path


def commit(repo, message, body=None, filename="file.txt"):
    with open(os.path.join(repo, filename), "a") as fh:
        fh.write(message + "\n")
    git(repo, "add", "-A")
    args = ["commit", "-q", "-m", message]
    if body:
        args += ["-m", body]
    git(repo, *args)
