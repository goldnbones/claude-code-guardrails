"""Tests for skills/changelog/scripts/changelog.py against real temporary git repos."""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

from helpers import CHANGELOG_SCRIPT, init_repo, commit, git


def run_changelog(repo, *args):
    return subprocess.run([sys.executable, CHANGELOG_SCRIPT, "--repo", repo] + list(args),
                          capture_output=True, text=True)


class ChangelogTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.root = tempfile.mkdtemp(prefix="changelog-test-")
        cls.repo = init_repo(os.path.join(cls.root, "repo"))
        git(cls.repo, "remote", "add", "origin", "git@github.com:acme/widgets.git")
        commit(cls.repo, "chore: initial scaffold")
        commit(cls.repo, "feat: old feature before tag")
        git(cls.repo, "tag", "-a", "v1.0.0", "-m", "v1.0.0")
        commit(cls.repo, "feat(auth): add magic-link sign in")
        commit(cls.repo, "fix: handle empty SQLite result sets (#42)")
        commit(cls.repo, "perf(db): cache prepared statements")
        commit(cls.repo, "docs: update README.")
        commit(cls.repo, "refactor(api): simplify router")
        commit(cls.repo, "feat(api)!: rename createUser to users.create",
               body="BREAKING CHANGE: clients must call users.create")
        commit(cls.repo, "chore(deps): bump next")
        commit(cls.repo, "Plain non-conventional message")
        commit(cls.repo, "fix(security): escape html in comments", body="Closes #77")
        commit(cls.repo, "revert: revert experimental cache")
        commit(cls.repo, "deprecate(api): v1 endpoints")
        commit(cls.repo, "remove: drop legacy import script")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.root, ignore_errors=True)

    def test_default_since_last_tag_markdown(self):
        res = run_changelog(self.repo)
        self.assertEqual(res.returncode, 0, res.stderr)
        out = res.stdout
        self.assertTrue(out.startswith("## [Unreleased]\n"), out[:80])
        # Section presence and ordering
        order = ["### Breaking Changes", "### Added", "### Changed", "### Deprecated",
                 "### Removed", "### Fixed", "### Security", "### Performance",
                 "### Documentation", "### Reverted"]
        positions = [out.index(h) for h in order]
        self.assertEqual(positions, sorted(positions), "sections out of Keep-a-Changelog order")
        # Entries
        self.assertIn("- **api:** Rename createUser to users.create -- clients must call users.create", out)
        self.assertIn("- **auth:** Add magic-link sign in", out)
        self.assertIn("- Handle empty SQLite result sets (#42)", out)
        self.assertNotIn("(#42) (#42)", out)
        self.assertIn("- **db:** Cache prepared statements", out)
        self.assertIn("- Update README (", out)               # trailing period stripped
        self.assertIn("- Escape html in comments (#77)", out)  # scope 'security' folded into section
        self.assertNotIn("**security:**", out)
        self.assertIn("- Revert experimental cache", out)
        self.assertIn("- **api:** V1 endpoints", out)
        self.assertIn("- Drop legacy import script", out)
        # Excluded by default
        self.assertNotIn("bump next", out)
        self.assertNotIn("Plain non-conventional", out)
        self.assertNotIn("old feature before tag", out)
        self.assertNotIn("### Other", out)
        # Links
        self.assertIn("https://github.com/acme/widgets/commit/", out)
        self.assertIn("[Unreleased]: https://github.com/acme/widgets/compare/v1.0.0...HEAD", out)

    def test_include_all_and_no_links(self):
        res = run_changelog(self.repo, "--include-all", "--no-links")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("### Other", res.stdout)
        self.assertIn("- **deps:** Bump next", res.stdout)
        self.assertIn("- Plain non-conventional message", res.stdout)
        self.assertNotIn("https://", res.stdout)
        self.assertNotIn("(", res.stdout.split("### Other")[0].split("### Added")[1].split("\n")[2])  # no hash suffix

    def test_explicit_since_and_until(self):
        res = run_changelog(self.repo, "--since", "v1.0.0", "--until", "v1.0.0~1", "--no-links")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("_No notable changes since v1.0.0._", res.stdout)
        res = run_changelog(self.repo, "--since", "HEAD~3", "--no-links")
        self.assertIn("V1 endpoints", res.stdout)
        self.assertNotIn("magic-link", res.stdout)

    def test_json_format(self):
        res = run_changelog(self.repo, "--format", "json", "--version", "2.0.0", "--date", "2026-01-02")
        self.assertEqual(res.returncode, 0, res.stderr)
        data = json.loads(res.stdout)
        self.assertEqual(data["version"], "2.0.0")
        self.assertEqual(data["date"], "2026-01-02")
        self.assertEqual(data["since"], "v1.0.0")
        self.assertEqual(len(data["sections"]["Added"]), 1)
        self.assertEqual(data["sections"]["Added"][0]["scope"], "auth")
        self.assertTrue(data["sections"]["Breaking Changes"][0]["breaking"])
        self.assertEqual(data["sections"]["Fixed"][0]["issues"], ["42"])
        self.assertNotIn("Other", data["sections"])

    def test_write_creates_and_is_idempotent(self):
        path = os.path.join(self.repo, "CHANGELOG.md")
        if os.path.exists(path):
            os.remove(path)
        res = run_changelog(self.repo, "--write", "--version", "1.1.0", "--date", "2026-09-14", "--no-links")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("wrote", res.stdout)
        with open(path) as fh:
            first = fh.read()
        self.assertTrue(first.startswith("# Changelog\n"))
        self.assertIn("Keep a Changelog", first)
        self.assertIn("## [1.1.0] - 2026-09-14", first)
        # Run again: same section replaced, not duplicated.
        run_changelog(self.repo, "--write", "--version", "1.1.0", "--date", "2026-09-14", "--no-links")
        with open(path) as fh:
            second = fh.read()
        self.assertEqual(first, second)
        self.assertEqual(second.count("## [1.1.0]"), 1)

    def test_write_inserts_new_version_above_existing_sections(self):
        path = os.path.join(self.repo, "CHANGELOG.md")
        with open(path, "w") as fh:
            fh.write("# Changelog\n\nIntro text.\n\n## [1.0.0] - 2026-01-01\n\n### Added\n\n- Something old\n")
        res = run_changelog(self.repo, "--write", "--version", "1.1.0", "--date", "2026-09-14", "--no-links")
        self.assertEqual(res.returncode, 0, res.stderr)
        with open(path) as fh:
            content = fh.read()
        self.assertLess(content.index("## [1.1.0]"), content.index("## [1.0.0]"))
        self.assertIn("Intro text.", content)
        self.assertIn("- Something old", content)
        # Replace the just-written section with new content and confirm the old one survives.
        run_changelog(self.repo, "--write", "--version", "1.1.0", "--date", "2026-09-15", "--no-links")
        with open(path) as fh:
            content = fh.read()
        self.assertEqual(content.count("## [1.1.0]"), 1)
        self.assertIn("2026-09-15", content)
        self.assertNotIn("2026-09-14", content)
        self.assertIn("## [1.0.0] - 2026-01-01", content)

    def test_write_to_custom_output(self):
        out = os.path.join(self.root, "custom.md")
        res = run_changelog(self.repo, "--write", "--output", out, "--no-links")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertTrue(os.path.exists(out))

    def test_repo_without_tags_uses_full_history(self):
        repo = init_repo(os.path.join(self.root, "notags"))
        commit(repo, "feat: first thing")
        commit(repo, "fix: second thing")
        res = run_changelog(repo, "--no-links")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("- First thing", res.stdout)
        self.assertIn("- Second thing", res.stdout)
        self.assertNotIn("compare/", res.stdout)

    def test_tag_pattern(self):
        repo = init_repo(os.path.join(self.root, "tagpattern"))
        commit(repo, "feat: a")
        git(repo, "tag", "v1.0.0")
        commit(repo, "feat: b")
        git(repo, "tag", "nightly-1")
        commit(repo, "feat: c")
        default = run_changelog(repo, "--no-links").stdout
        self.assertNotIn("- B", default)
        patterned = run_changelog(repo, "--no-links", "--tag-pattern", "v*").stdout
        self.assertIn("- B", patterned)
        self.assertIn("- C", patterned)

    def test_gitlab_and_https_remote_detection(self):
        repo = init_repo(os.path.join(self.root, "gitlab"))
        git(repo, "remote", "add", "origin", "https://gitlab.com/group/proj.git")
        commit(repo, "feat: x")
        out = run_changelog(repo).stdout
        self.assertIn("https://gitlab.com/group/proj/-/commit/", out)

    def test_not_a_repo_exits_2(self):
        empty = os.path.join(self.root, "empty")
        os.makedirs(empty, exist_ok=True)
        res = run_changelog(empty)
        self.assertEqual(res.returncode, 2)
        self.assertIn("changelog:", res.stderr)

    def test_merge_commits_excluded_by_default(self):
        repo = init_repo(os.path.join(self.root, "merges"))
        commit(repo, "feat: base")
        git(repo, "checkout", "-q", "-b", "topic")
        commit(repo, "fix: on topic", filename="topic.txt")
        git(repo, "checkout", "-q", "main")
        commit(repo, "feat: on main", filename="main.txt")
        git(repo, "merge", "--no-ff", "-q", "-m", "Merge branch 'topic'", "topic")
        default = run_changelog(repo, "--no-links", "--include-all").stdout
        self.assertNotIn("Merge branch", default)
        with_merges = run_changelog(repo, "--no-links", "--include-all", "--include-merges").stdout
        self.assertIn("Merge branch", with_merges)


if __name__ == "__main__":
    unittest.main()
