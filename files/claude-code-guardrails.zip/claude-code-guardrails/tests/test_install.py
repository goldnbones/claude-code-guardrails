"""Tests for install.sh: copies files, merges settings.json idempotently, uninstalls."""

import json
import os
import shutil
import stat
import subprocess
import tempfile
import unittest

from helpers import INSTALL_SH, PACK_DIR

EXPECTED_FILES = [
    ".claude/hooks/guard-destructive.py",
    ".claude/hooks/guard-secrets.py",
    ".claude/skills/changelog/SKILL.md",
    ".claude/skills/changelog/scripts/changelog.py",
    ".claude/agents/pr-reviewer.md",
    ".claude/guardrails.json",
    "CLAUDE.md.nextjs-sqlite.template",
]


def run_install(*args, env=None):
    return subprocess.run(["bash", INSTALL_SH] + list(args), capture_output=True, text=True, env=env)


def read_json(path):
    with open(path) as fh:
        return json.load(fh)


def hook_commands(settings):
    out = {}
    for entry in settings.get("hooks", {}).get("PreToolUse", []):
        out.setdefault(entry["matcher"], []).extend(h["command"] for h in entry["hooks"])
    return out


class InstallTests(unittest.TestCase):

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="install-test-")
        self.target = os.path.join(self.root, "proj")
        os.makedirs(self.target)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_fresh_install_creates_everything(self):
        res = run_install(self.target)
        self.assertEqual(res.returncode, 0, res.stderr + res.stdout)
        for rel in EXPECTED_FILES:
            self.assertTrue(os.path.exists(os.path.join(self.target, rel)), rel)
        settings = read_json(os.path.join(self.target, ".claude", "settings.json"))
        cmds = hook_commands(settings)
        self.assertEqual(cmds["Bash"], ['python3 "$CLAUDE_PROJECT_DIR"/.claude/hooks/guard-destructive.py'])
        self.assertEqual(cmds["Edit|Write|MultiEdit|NotebookEdit"], ['python3 "$CLAUDE_PROJECT_DIR"/.claude/hooks/guard-secrets.py'])
        for entry in settings["hooks"]["PreToolUse"]:
            for h in entry["hooks"]:
                self.assertEqual(h["type"], "command")
        # Installed hooks are executable and byte-identical to the pack.
        for name in ("guard-destructive.py", "guard-secrets.py"):
            dst = os.path.join(self.target, ".claude", "hooks", name)
            self.assertTrue(os.stat(dst).st_mode & stat.S_IXUSR)
            with open(dst) as a, open(os.path.join(PACK_DIR, "hooks", name)) as b:
                self.assertEqual(a.read(), b.read())
        # guardrails.json is valid JSON with both sections.
        cfg = read_json(os.path.join(self.target, ".claude", "guardrails.json"))
        self.assertIn("destructive", cfg)
        self.assertIn("secrets", cfg)

    def test_installed_hook_actually_blocks(self):
        run_install(self.target)
        hook = os.path.join(self.target, ".claude", "hooks", "guard-destructive.py")
        env = dict(os.environ, HOME=self.root, CLAUDE_PROJECT_DIR=self.target)
        res = subprocess.run(["python3", hook], input='{"tool_name":"Bash","tool_input":{"command":"rm -rf /"}}',
                             capture_output=True, text=True, env=env)
        self.assertEqual(res.returncode, 2)

    def test_idempotent_reinstall(self):
        run_install(self.target)
        settings_path = os.path.join(self.target, ".claude", "settings.json")
        with open(settings_path) as fh:
            first = fh.read()
        cfg_path = os.path.join(self.target, ".claude", "guardrails.json")
        with open(cfg_path, "w") as fh:
            fh.write('{"destructive": {"allow_patterns": ["^custom$"]}}')
        res = run_install(self.target)
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("unchanged", res.stdout)
        with open(settings_path) as fh:
            self.assertEqual(fh.read(), first)
        with open(cfg_path) as fh:
            self.assertIn("custom", fh.read(), "user config must not be overwritten")
        cmds = hook_commands(read_json(settings_path))
        self.assertEqual(len(cmds["Bash"]), 1)
        self.assertEqual(len(cmds["Edit|Write|MultiEdit|NotebookEdit"]), 1)

    def test_merges_into_existing_settings_preserving_content(self):
        claude_dir = os.path.join(self.target, ".claude")
        os.makedirs(claude_dir)
        existing = {
            "permissions": {"allow": ["Bash(ls:*)"]},
            "env": {"FOO": "bar"},
            "hooks": {
                "PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command", "command": "echo existing"}]}],
                "PostToolUse": [{"matcher": "Write", "hooks": [{"type": "command", "command": "prettier"}]}],
            },
        }
        with open(os.path.join(claude_dir, "settings.json"), "w") as fh:
            json.dump(existing, fh)
        res = run_install(self.target)
        self.assertEqual(res.returncode, 0, res.stderr)
        settings = read_json(os.path.join(claude_dir, "settings.json"))
        self.assertEqual(settings["permissions"], existing["permissions"])
        self.assertEqual(settings["env"], existing["env"])
        self.assertEqual(settings["hooks"]["PostToolUse"], existing["hooks"]["PostToolUse"])
        cmds = hook_commands(settings)
        self.assertEqual(cmds["Bash"][0], "echo existing")
        self.assertIn("guard-destructive.py", cmds["Bash"][1])
        self.assertTrue(os.path.exists(os.path.join(claude_dir, "settings.json.bak")))

    def test_invalid_existing_settings_aborts_without_clobbering(self):
        claude_dir = os.path.join(self.target, ".claude")
        os.makedirs(claude_dir)
        with open(os.path.join(claude_dir, "settings.json"), "w") as fh:
            fh.write("{ broken")
        res = run_install(self.target)
        self.assertNotEqual(res.returncode, 0)
        self.assertIn("not valid JSON", res.stderr)
        with open(os.path.join(claude_dir, "settings.json")) as fh:
            self.assertEqual(fh.read(), "{ broken")

    def test_uninstall_removes_only_ours(self):
        claude_dir = os.path.join(self.target, ".claude")
        os.makedirs(claude_dir)
        with open(os.path.join(claude_dir, "settings.json"), "w") as fh:
            json.dump({"hooks": {"PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command", "command": "echo keep"}]}]}}, fh)
        run_install(self.target)
        res = run_install(self.target, "--uninstall")
        self.assertEqual(res.returncode, 0, res.stderr)
        for rel in EXPECTED_FILES:
            if rel.endswith(("guardrails.json", ".template")):
                continue
            self.assertFalse(os.path.exists(os.path.join(self.target, rel)), rel + " should be removed")
        settings = read_json(os.path.join(claude_dir, "settings.json"))
        cmds = hook_commands(settings)
        self.assertEqual(cmds, {"Bash": ["echo keep"]})
        # Uninstall on a clean target is a no-op that still succeeds.
        res = run_install(self.target, "--uninstall")
        self.assertEqual(res.returncode, 0, res.stderr)

    def test_uninstall_leaves_no_empty_hooks_object(self):
        run_install(self.target)
        run_install(self.target, "--uninstall")
        settings = read_json(os.path.join(self.target, ".claude", "settings.json"))
        self.assertNotIn("hooks", settings)

    def test_dry_run_changes_nothing(self):
        res = run_install(self.target, "--dry-run")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("[dry-run]", res.stdout)
        self.assertFalse(os.path.exists(os.path.join(self.target, ".claude")))

    def test_no_config_and_no_template_flags(self):
        res = run_install(self.target, "--no-config", "--no-template")
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertFalse(os.path.exists(os.path.join(self.target, ".claude", "guardrails.json")))
        self.assertFalse(os.path.exists(os.path.join(self.target, "CLAUDE.md.nextjs-sqlite.template")))
        self.assertTrue(os.path.exists(os.path.join(self.target, ".claude", "hooks", "guard-destructive.py")))

    def test_force_overwrites_config(self):
        run_install(self.target)
        cfg_path = os.path.join(self.target, ".claude", "guardrails.json")
        with open(cfg_path, "w") as fh:
            fh.write("{}")
        run_install(self.target, "--force")
        self.assertIn("destructive", read_json(cfg_path))

    def test_global_install_uses_home(self):
        home = os.path.join(self.root, "home")
        os.makedirs(home)
        env = dict(os.environ, HOME=home)
        res = run_install("--global", env=env)
        self.assertEqual(res.returncode, 0, res.stderr)
        settings = read_json(os.path.join(home, ".claude", "settings.json"))
        cmds = hook_commands(settings)
        self.assertEqual(cmds["Bash"], ['python3 "$HOME"/.claude/hooks/guard-destructive.py'])
        self.assertTrue(os.path.exists(os.path.join(home, ".claude", "agents", "pr-reviewer.md")))
        self.assertFalse(os.path.exists(os.path.join(home, "CLAUDE.md.nextjs-sqlite.template")))
        res = run_install("--global", "sometarget", env=env)
        self.assertNotEqual(res.returncode, 0)

    def test_bad_arguments(self):
        self.assertNotEqual(run_install("--bogus").returncode, 0)
        self.assertNotEqual(run_install(os.path.join(self.root, "missing")).returncode, 0)
        self.assertNotEqual(run_install(self.target, self.target).returncode, 0)
        res = run_install("--help")
        self.assertEqual(res.returncode, 0)
        self.assertIn("--uninstall", res.stdout)


if __name__ == "__main__":
    unittest.main()
