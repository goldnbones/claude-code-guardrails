#!/usr/bin/env python3
"""
guard-secrets.py -- Claude Code PreToolUse hook for Edit / Write / MultiEdit
/ NotebookEdit.

Blocks Claude from writing credential-looking strings into files that are
(or will be) committed to git.

Contract (Claude Code hooks):
    stdin   JSON: {"session_id": "...", "tool_name": "Write",
                   "tool_input": {"file_path": "...", "content": "..."},
                   "cwd": "..."}
            Edit:        tool_input.new_string
            MultiEdit:   tool_input.edits[].new_string
            NotebookEdit tool_input.new_source
    exit 0  allow
    exit 2  BLOCK; stderr is shown to Claude

Detection (rule ids in parentheses; disable via "disabled_rules"):
    aws_access_key, aws_secret_key, private_key, anthropic_api_key,
    openai_api_key, stripe_secret_key, github_token, gitlab_token,
    slack_token, slack_webhook, google_api_key, google_oauth_secret,
    sendgrid_api_key, twilio_api_key, npm_token, pypi_token,
    huggingface_token, digitalocean_token, shopify_token, mailgun_key,
    telegram_bot_token, discord_bot_token, linear_api_key, notion_token,
    resend_api_key, planetscale_token, age_secret_key, jwt,
    connection_string_password, generic_assignment (entropy-based)

Which files are scanned:
    * Files tracked by git are ALWAYS scanned (a tracked .env is still tracked).
    * Untracked files that git ignores (.gitignore) are skipped.
    * Untracked files matching "allow_files" (.env, .env.local, ...) are
      skipped, unless they look like templates (.env.example, *.sample ...).
    * Everything else is scanned. Outside a git repo everything is scanned
      (set "scan_outside_git": false to change).

Escape hatches:
    * Well-known documentation placeholders (AKIAIOSFODNN7EXAMPLE, values
      containing EXAMPLE/XXXX/CHANGEME/<...>/${...}) are ignored.
    * A line containing `guardrails-allow-secret` is skipped.
    * "allow_patterns": regexes matched against the detected value.

Configuration lives under the "secrets" key of .claude/guardrails.json.
Dependency-free: Python 3.8+ standard library only.
"""

import fnmatch
import json
import math
import os
import re
import subprocess
import sys

HOOK_NAME = "guard-secrets"
INLINE_ALLOW_MARKER = "guardrails-allow-secret"

DEFAULT_CONFIG = {
    # Untracked files matching these globs may contain secrets.
    "allow_files": [".env", ".env.*", "*.env", ".envrc", "*.local",
                    ".npmrc", ".pypirc", ".netrc", "secrets.json",
                    "secrets.yaml", "secrets.yml", "*.secret", "*.secrets"],
    # Globs that override allow_files (templates that DO get committed).
    "template_suffixes": [".example", ".sample", ".template", ".dist",
                          ".md", ".mdx", ".txt", ".rst"],
    # Regexes matched against the *detected value*; matches are ignored.
    "allow_patterns": [],
    # Rule ids to disable.
    "disabled_rules": [],
    # Substrings (case-insensitive) that mark a value as a placeholder.
    "placeholder_words": ["example", "xxxx", "changeme", "your_", "your-",
                          "yourkey", "placeholder", "dummy", "sample",
                          "redacted", "<", ">", "${", "{{", "process.env",
                          "os.environ", "getenv", "000000000000", "aaaaaaaaaa",
                          "1234567890123456", "todo", "insert", "replace"],
    # Skip files git ignores.
    "respect_gitignore": True,
    # Scan files that are not inside a git repository at all.
    "scan_outside_git": True,
    # Minimum Shannon entropy (bits/char) for generic assignments.
    "generic_min_entropy": 3.5,
    # Minimum length for generic assignment values.
    "generic_min_length": 16,
    # If stdin is unreadable/malformed, block (True) or allow (False).
    "fail_closed": False,
}
LIST_KEYS = {"allow_files", "template_suffixes", "allow_patterns",
             "disabled_rules", "placeholder_words"}


def _read_json_file(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def load_config(cwd):
    cfg = {k: (list(v) if isinstance(v, list) else v) for k, v in DEFAULT_CONFIG.items()}
    candidates = [os.path.join(os.path.expanduser("~"), ".claude", "guardrails.json")]
    proj = os.environ.get("CLAUDE_PROJECT_DIR")
    if proj:
        candidates.append(os.path.join(proj, ".claude", "guardrails.json"))
    if cwd:
        candidates.append(os.path.join(cwd, ".claude", "guardrails.json"))
    env_path = os.environ.get("GUARDRAILS_CONFIG")
    if env_path:
        candidates.append(env_path)
    seen = set()
    for path in candidates:
        path = os.path.abspath(path)
        if path in seen or not os.path.isfile(path):
            continue
        seen.add(path)
        section = _read_json_file(path).get("secrets")
        if not isinstance(section, dict):
            continue
        for key, value in section.items():
            if key.startswith("_"):
                continue
            if key in LIST_KEYS and isinstance(value, list):
                for item in value:
                    # Strings starting with "_" are documentation, not config.
                    if isinstance(item, str) and not item.startswith("_") and item not in cfg[key]:
                        cfg[key].append(item)
            elif key in DEFAULT_CONFIG and not isinstance(DEFAULT_CONFIG[key], list):
                cfg[key] = value
    return cfg


# --------------------------------------------------------------------------- #
# Patterns
# --------------------------------------------------------------------------- #

# (rule_id, compiled regex, description). Group 1 (if any) is the secret value.
PATTERNS = [
    ("private_key",
     re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED |PRIVATE )?PRIVATE KEY(?: BLOCK)?-----"),
     "private key block"),
    ("aws_access_key",
     re.compile(r"(?<![A-Z0-9])((?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA)[A-Z0-9]{16})(?![A-Z0-9])"),
     "AWS access key ID"),
    ("aws_secret_key",
     re.compile(r"(?i)aws[_\-\s]*secret[_\-\s]*(?:access[_\-\s]*)?key[\"']?\s*[:=]\s*[\"']?([A-Za-z0-9/+=]{40})(?![A-Za-z0-9/+=])"),
     "AWS secret access key"),
    ("anthropic_api_key",
     re.compile(r"(sk-ant-[A-Za-z0-9_\-]{20,})"),
     "Anthropic API key"),
    ("openai_api_key",
     re.compile(r"(?<![A-Za-z0-9_\-])(sk-(?!ant-)(?:proj-|svcacct-|admin-)?[A-Za-z0-9_\-]{20,})(?![A-Za-z0-9_\-])"),
     "OpenAI-style secret key (sk-...)"),
    ("stripe_secret_key",
     re.compile(r"(?<![A-Za-z0-9])([sr]k_(?:live|test)_[A-Za-z0-9]{20,})"),
     "Stripe secret key"),
    ("github_token",
     re.compile(r"(?<![A-Za-z0-9])((?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{22,})"),
     "GitHub token"),
    ("gitlab_token",
     re.compile(r"(glpat-[A-Za-z0-9\-_]{20,})"),
     "GitLab personal access token"),
    ("slack_token",
     re.compile(r"(xox[baprs]-[0-9A-Za-z\-]{10,})"),
     "Slack token"),
    ("slack_webhook",
     re.compile(r"(https://hooks\.slack\.com/services/T[A-Za-z0-9]+/B[A-Za-z0-9]+/[A-Za-z0-9]{20,})"),
     "Slack incoming webhook URL"),
    ("google_api_key",
     re.compile(r"(AIza[0-9A-Za-z_\-]{35})"),
     "Google API key"),
    ("google_oauth_secret",
     re.compile(r"(GOCSPX-[A-Za-z0-9_\-]{20,})"),
     "Google OAuth client secret"),
    ("sendgrid_api_key",
     re.compile(r"(SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43})"),
     "SendGrid API key"),
    ("twilio_api_key",
     re.compile(r"(?<![A-Za-z0-9])(SK[0-9a-f]{32})(?![A-Za-z0-9])"),
     "Twilio API key"),
    ("npm_token",
     re.compile(r"(npm_[A-Za-z0-9]{36})"),
     "npm access token"),
    ("pypi_token",
     re.compile(r"(pypi-AgEIcHlwaS5vcmc[A-Za-z0-9_\-]{40,})"),
     "PyPI API token"),
    ("huggingface_token",
     re.compile(r"(?<![A-Za-z0-9])(hf_[A-Za-z0-9]{30,})"),
     "Hugging Face token"),
    ("digitalocean_token",
     re.compile(r"(do[opr]_v1_[a-f0-9]{64})"),
     "DigitalOcean token"),
    ("shopify_token",
     re.compile(r"(shp(?:at|ca|pa|ss)_[0-9a-fA-F]{32})"),
     "Shopify access token"),
    ("mailgun_key",
     re.compile(r"(?<![A-Za-z0-9])(key-[0-9a-f]{32})(?![A-Za-z0-9])"),
     "Mailgun API key"),
    ("telegram_bot_token",
     re.compile(r"(?<![0-9])(\d{8,10}:AA[0-9A-Za-z_\-]{33})"),
     "Telegram bot token"),
    ("discord_bot_token",
     re.compile(r"(?<![A-Za-z0-9])([MN][A-Za-z0-9_\-]{23,}\.[A-Za-z0-9_\-]{6}\.[A-Za-z0-9_\-]{27,})"),
     "Discord bot token"),
    ("linear_api_key",
     re.compile(r"(lin_api_[A-Za-z0-9]{40})"),
     "Linear API key"),
    ("notion_token",
     re.compile(r"(?<![A-Za-z0-9])((?:secret|ntn)_[A-Za-z0-9]{43})"),
     "Notion integration token"),
    ("resend_api_key",
     re.compile(r"(?<![A-Za-z0-9])(re_[A-Za-z0-9]{8}_[A-Za-z0-9]{24,})"),
     "Resend API key"),
    ("planetscale_token",
     re.compile(r"(pscale_(?:tkn|oauth|pw)_[A-Za-z0-9_\-.]{20,})"),
     "PlanetScale token"),
    ("age_secret_key",
     re.compile(r"(AGE-SECRET-KEY-1[A-Z0-9]{58})"),
     "age secret key"),
    ("jwt",
     re.compile(r"(?<![A-Za-z0-9_\-])(eyJ[A-Za-z0-9_\-]{8,}\.eyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,})"),
     "JSON Web Token (JWT)"),
]

CONNECTION_STRING_RE = re.compile(
    r"(?i)\b((?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\+srv)?|redis|rediss|amqps?|mssql|sqlserver|"
    r"ftp|sftp|smtps?|ldaps?|https?)://([^:/\s@\"']+):([^@\s\"']{4,})@([^/\s\"':]+))")
LOCAL_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0", "::1", "db", "database",
               "postgres", "mysql", "redis", "mongo", "host.docker.internal"}

GENERIC_ASSIGNMENT_RE = re.compile(
    r"(?i)\b([A-Za-z0-9_\-.]*(?:password|passwd|pwd|secret|api[_\-]?key|apikey|access[_\-]?key|"
    r"auth[_\-]?token|private[_\-]?key|client[_\-]?secret|token)[A-Za-z0-9_\-.]*)[\"']?\s*"
    r"(?:[:=]|=>|:=)\s*[\"']([^\"'\n]{8,})[\"']")
GENERIC_NAME_EXCLUDE = re.compile(
    r"(?i)(_?(?:name|id|file|path|url|uri|type|kind|header|param|field|key_?name|prefix|"
    r"suffix|label|env|var|len|length|size|format|regex|pattern|schema|table|column|placeholder|hint|title|description))$")

WELL_KNOWN_FAKES = {
    "AKIAIOSFODNN7EXAMPLE", "AKIAI44QH8DHBEXAMPLE",
    "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    "je7MtGbClwBF/2Zp9Utk/h3yCo8nvbEXAMPLEKEY",
}


def shannon_entropy(value):
    if not value:
        return 0.0
    counts = {}
    for ch in value:
        counts[ch] = counts.get(ch, 0) + 1
    length = float(len(value))
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def is_placeholder(value, cfg):
    if value in WELL_KNOWN_FAKES:
        return True
    low = value.lower()
    for word in cfg.get("placeholder_words", []):
        if word.lower() in low:
            return True
    # Repeated single character or obviously sequential filler.
    if len(set(low.replace("-", "").replace("_", ""))) <= 3:
        return True
    return False


def allowed_by_pattern(value, cfg):
    for pat in cfg.get("allow_patterns", []):
        try:
            if re.search(pat, value):
                return True
        except re.error:
            continue
    return False


def mask(value):
    if len(value) <= 10:
        return value[:2] + "*" * max(len(value) - 2, 0)
    return value[:4] + "..." + value[-4:]


# --------------------------------------------------------------------------- #
# Scanning
# --------------------------------------------------------------------------- #

class Finding(object):
    def __init__(self, rule, description, line_no, value):
        self.rule = rule
        self.description = description
        self.line_no = line_no
        self.value = value


def scan_text(text, cfg, line_offset=0):
    """Return a list of Finding for every credential-looking value in text."""
    findings = []
    disabled = set(cfg.get("disabled_rules", []))
    lines = text.split("\n")
    for idx, line in enumerate(lines):
        if INLINE_ALLOW_MARKER in line:
            continue
        line_no = line_offset + idx + 1
        consumed = []          # (start, end) spans already attributed

        def overlaps(span):
            return any(s < span[1] and span[0] < e for s, e in consumed)

        for rule, regex, description in PATTERNS:
            if rule in disabled:
                continue
            for m in regex.finditer(line):
                span = m.span(1) if m.groups() else m.span(0)
                value = m.group(1) if m.groups() else m.group(0)
                if overlaps(span):
                    continue
                if rule != "private_key" and (is_placeholder(value, cfg) or allowed_by_pattern(value, cfg)):
                    continue
                consumed.append(span)
                findings.append(Finding(rule, description, line_no, value))

        if "connection_string_password" not in disabled:
            for m in CONNECTION_STRING_RE.finditer(line):
                whole, user, password, host = m.group(1), m.group(2), m.group(3), m.group(4)
                if overlaps(m.span(1)):
                    continue
                host_name = host.split(":")[0].lower()
                if host_name in LOCAL_HOSTS or password.lower() == user.lower():
                    continue
                if password.lower() in ("password", "pass", "secret", "pwd", "root", "admin", "test", "postgres", "mysql", "redis"):
                    continue
                if is_placeholder(password, cfg) or allowed_by_pattern(password, cfg) or allowed_by_pattern(whole, cfg):
                    continue
                consumed.append(m.span(1))
                findings.append(Finding("connection_string_password", "connection string with embedded password", line_no, whole))

        if "generic_assignment" not in disabled:
            for m in GENERIC_ASSIGNMENT_RE.finditer(line):
                name, value = m.group(1), m.group(2)
                if overlaps(m.span(2)) or GENERIC_NAME_EXCLUDE.search(name):
                    continue
                if len(value) < int(cfg.get("generic_min_length", 16)):
                    continue
                if is_placeholder(value, cfg) or allowed_by_pattern(value, cfg):
                    continue
                if " " in value.strip() or value.count("/") > 3:
                    continue           # sentences / paths are not secrets
                if shannon_entropy(value) < float(cfg.get("generic_min_entropy", 3.5)):
                    continue
                classes = sum(bool(re.search(p, value)) for p in (r"[a-z]", r"[A-Z]", r"[0-9]", r"[^A-Za-z0-9]"))
                if classes < 2:
                    continue
                consumed.append(m.span(2))
                findings.append(Finding("generic_assignment", "high-entropy value assigned to `%s`" % name, line_no, value))
    return findings


# --------------------------------------------------------------------------- #
# File classification
# --------------------------------------------------------------------------- #

def _git(args, cwd, timeout=3):
    try:
        res = subprocess.run(["git"] + args, cwd=cwd or None, capture_output=True, text=True, timeout=timeout)
        return res.returncode, res.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None, ""


def file_status(file_path, cwd):
    """Return one of: 'tracked', 'ignored', 'untracked', 'no-repo'."""
    directory = os.path.dirname(os.path.abspath(file_path)) or cwd
    probe_dir = directory
    while probe_dir and not os.path.isdir(probe_dir):
        probe_dir = os.path.dirname(probe_dir)
    code, out = _git(["rev-parse", "--is-inside-work-tree"], probe_dir)
    if code != 0 or out != "true":
        return "no-repo"
    code, _ = _git(["ls-files", "--error-unmatch", "--", os.path.abspath(file_path)], probe_dir)
    if code == 0:
        return "tracked"
    code, _ = _git(["check-ignore", "-q", "--", os.path.abspath(file_path)], probe_dir)
    if code == 0:
        return "ignored"
    return "untracked"


def matches_allow_files(file_path, cfg):
    name = os.path.basename(file_path)
    if any(name.endswith(suffix) for suffix in cfg.get("template_suffixes", [])):
        return False
    rel = file_path.replace(os.sep, "/")
    for pat in cfg.get("allow_files", []):
        if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(rel, "*/" + pat):
            return True
    return False


def should_scan(file_path, cwd, cfg):
    """Decide whether the target file must be scanned; return (bool, why)."""
    if not file_path:
        return True, "no file path supplied"
    status = file_status(file_path, cwd)
    if status == "tracked":
        return True, "file is tracked by git"
    if status == "no-repo":
        if not cfg.get("scan_outside_git", True):
            return False, "outside a git repository"
        return True, "outside a git repository (scan_outside_git=true)"
    if status == "ignored" and cfg.get("respect_gitignore", True):
        return False, "file is git-ignored"
    if matches_allow_files(file_path, cfg):
        return False, "file matches allow_files"
    return True, "file would be committed"


# --------------------------------------------------------------------------- #
# Hook input -> candidate texts
# --------------------------------------------------------------------------- #

def collect_texts(tool_name, tool_input):
    """Return list of (label, text) chunks that are about to be written."""
    chunks = []
    if tool_name == "Write":
        chunks.append(("content", tool_input.get("content") or ""))
    elif tool_name == "Edit":
        chunks.append(("new_string", tool_input.get("new_string") or ""))
    elif tool_name == "MultiEdit":
        for i, edit in enumerate(tool_input.get("edits") or []):
            if isinstance(edit, dict):
                chunks.append(("edits[%d].new_string" % i, edit.get("new_string") or ""))
    elif tool_name == "NotebookEdit":
        chunks.append(("new_source", tool_input.get("new_source") or ""))
    else:
        return []
    return [(label, text) for label, text in chunks if isinstance(text, str) and text]


def format_block_message(file_path, findings, why):
    lines = ["BLOCKED by %s: credential-looking content would be written to %s" % (HOOK_NAME, file_path or "<unknown file>"),
             "  (%s)" % why]
    for f in findings[:10]:
        lines.append("  - line %d: %s [rule: %s] value: %s" % (f.line_no, f.description, f.rule, mask(f.value)))
    if len(findings) > 10:
        lines.append("  ... and %d more" % (len(findings) - 10))
    lines.append("  Fix: keep the real value in an untracked .env / secret store and reference it via an")
    lines.append("  environment variable. If this is a deliberate placeholder, use an obvious fake value")
    lines.append("  (e.g. containing EXAMPLE) or append `# %s` to the line." % INLINE_ALLOW_MARKER)
    return "\n".join(lines) + "\n"


def main():
    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw.strip() else {}
        if not isinstance(payload, dict):
            raise ValueError("payload is not an object")
    except (ValueError, OSError) as exc:
        cfg = load_config(None)
        if cfg.get("fail_closed"):
            sys.stderr.write("BLOCKED by %s: could not parse hook input (%s)\n" % (HOOK_NAME, exc))
            return 2
        sys.stderr.write("%s: warning: could not parse hook input (%s); allowing\n" % (HOOK_NAME, exc))
        return 0

    tool_name = payload.get("tool_name", "")
    tool_input = payload.get("tool_input") or {}
    if not isinstance(tool_input, dict):
        return 0
    chunks = collect_texts(tool_name, tool_input)
    if not chunks:
        return 0
    cwd = payload.get("cwd") or os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()
    file_path = tool_input.get("file_path") or tool_input.get("notebook_path") or ""
    if file_path and not os.path.isabs(file_path):
        file_path = os.path.join(cwd, file_path)

    cfg = load_config(cwd)
    try:
        scan, why = should_scan(file_path, cwd, cfg)
        if not scan:
            return 0
        findings = []
        for label, text in chunks:
            for f in scan_text(text, cfg):
                f.description = "%s (%s)" % (f.description, label) if label != "content" else f.description
                findings.append(f)
        if findings:
            sys.stderr.write(format_block_message(file_path, findings, why))
            return 2
    except Exception as exc:  # never crash Claude Code because of the guard
        if cfg.get("fail_closed"):
            sys.stderr.write("BLOCKED by %s: internal error (%s: %s)\n" % (HOOK_NAME, type(exc).__name__, exc))
            return 2
        sys.stderr.write("%s: warning: internal error (%s: %s); allowing\n" % (HOOK_NAME, type(exc).__name__, exc))
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
