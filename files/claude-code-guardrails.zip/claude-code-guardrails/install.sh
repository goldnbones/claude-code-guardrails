#!/usr/bin/env bash
#
# install.sh -- install the Claude Code Guardrails & Workflow Pack into a project.
#
#   ./install.sh [TARGET_DIR] [options]
#
#   TARGET_DIR          project root (default: current directory). Files go to
#                       TARGET_DIR/.claude/ and hook entries are merged into
#                       TARGET_DIR/.claude/settings.json.
#
#   --global            install into ~/.claude instead (applies to every project)
#   --uninstall         remove the pack's files and hook entries
#   --dry-run           print what would happen without changing anything
#   --no-config         do not create .claude/guardrails.json
#   --no-template       do not copy the CLAUDE.md template
#   --force             overwrite an existing guardrails.json / CLAUDE.md template copy
#   -h, --help          this text
#
# Idempotent: re-running never duplicates hook entries or clobbers your config.
# Requires: bash, python3 (3.8+). No other dependencies.

set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=""
GLOBAL=0
UNINSTALL=0
DRY_RUN=0
NO_CONFIG=0
NO_TEMPLATE=0
FORCE=0

usage() { sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; }

for arg in "$@"; do
  case "$arg" in
    --global) GLOBAL=1 ;;
    --uninstall) UNINSTALL=1 ;;
    --dry-run) DRY_RUN=1 ;;
    --no-config) NO_CONFIG=1 ;;
    --no-template) NO_TEMPLATE=1 ;;
    --force) FORCE=1 ;;
    -h|--help) usage; exit 0 ;;
    -*) echo "install.sh: unknown option: $arg" >&2; usage >&2; exit 1 ;;
    *) if [[ -n "$TARGET" ]]; then echo "install.sh: only one TARGET_DIR allowed" >&2; exit 1; fi; TARGET="$arg" ;;
  esac
done

if ! command -v python3 >/dev/null 2>&1; then
  echo "install.sh: python3 is required (hooks and the JSON merge use it)." >&2
  exit 1
fi

if [[ $GLOBAL -eq 1 ]]; then
  if [[ -n "$TARGET" ]]; then echo "install.sh: --global does not take a TARGET_DIR" >&2; exit 1; fi
  CLAUDE_DIR="${HOME}/.claude"
  HOOK_PREFIX='"$HOME"/.claude/hooks'
else
  TARGET="${TARGET:-.}"
  if [[ ! -d "$TARGET" ]]; then echo "install.sh: target directory not found: $TARGET" >&2; exit 1; fi
  TARGET="$(cd "$TARGET" && pwd)"
  CLAUDE_DIR="${TARGET}/.claude"
  HOOK_PREFIX='"$CLAUDE_PROJECT_DIR"/.claude/hooks'
fi

SETTINGS="${CLAUDE_DIR}/settings.json"
CMD_DESTRUCTIVE="python3 ${HOOK_PREFIX}/guard-destructive.py"
CMD_SECRETS="python3 ${HOOK_PREFIX}/guard-secrets.py"

log() { printf '%s\n' "$*"; }
run() { if [[ $DRY_RUN -eq 1 ]]; then log "[dry-run] $*"; else "$@"; fi; }

copy_file() { # src dst
  local src="$1" dst="$2"
  run mkdir -p "$(dirname "$dst")"
  run cp "$src" "$dst"
  log "  installed $dst"
}

merge_settings() { # mode: install|uninstall
  local mode="$1"
  if [[ $DRY_RUN -eq 1 ]]; then
    log "[dry-run] would ${mode} hook entries in ${SETTINGS}"
    return
  fi
  mkdir -p "$CLAUDE_DIR"
  python3 - "$SETTINGS" "$mode" "$CMD_DESTRUCTIVE" "$CMD_SECRETS" <<'PYEOF'
import json, os, shutil, sys

settings_path, mode, cmd_destructive, cmd_secrets = sys.argv[1:5]
ENTRIES = [
    ("Bash", cmd_destructive),
    ("Edit|Write|MultiEdit|NotebookEdit", cmd_secrets),
]
OUR_SCRIPTS = ("guard-destructive.py", "guard-secrets.py")

data = {}
if os.path.exists(settings_path):
    with open(settings_path, "r", encoding="utf-8") as fh:
        raw = fh.read()
    if raw.strip():
        try:
            data = json.loads(raw)
        except ValueError as exc:
            sys.stderr.write("install.sh: %s is not valid JSON (%s); fix it or move it aside.\n" % (settings_path, exc))
            sys.exit(1)
    if not isinstance(data, dict):
        sys.stderr.write("install.sh: %s must contain a JSON object.\n" % settings_path)
        sys.exit(1)

original = json.dumps(data, sort_keys=True)
hooks = data.setdefault("hooks", {})
if not isinstance(hooks, dict):
    sys.stderr.write("install.sh: 'hooks' in settings.json must be an object.\n")
    sys.exit(1)
pre = hooks.setdefault("PreToolUse", [])
if not isinstance(pre, list):
    sys.stderr.write("install.sh: 'hooks.PreToolUse' must be a list.\n")
    sys.exit(1)

def is_ours(hook):
    cmd = hook.get("command", "") if isinstance(hook, dict) else ""
    return any(s in cmd for s in OUR_SCRIPTS)

if mode == "install":
    for matcher, command in ENTRIES:
        entry = next((e for e in pre if isinstance(e, dict) and e.get("matcher") == matcher), None)
        if entry is None:
            entry = {"matcher": matcher, "hooks": []}
            pre.append(entry)
        entry_hooks = entry.setdefault("hooks", [])
        script = os.path.basename(command.rstrip('"'))
        existing = next((h for h in entry_hooks if isinstance(h, dict) and script in h.get("command", "")), None)
        if existing is None:
            entry_hooks.append({"type": "command", "command": command})
            print("  added hook   [%s] %s" % (matcher, command))
        else:
            if existing.get("command") != command:
                existing["command"] = command
                print("  updated hook [%s] %s" % (matcher, command))
            else:
                print("  hook present [%s] (unchanged)" % matcher)
else:
    removed = 0
    for entry in list(pre):
        if not isinstance(entry, dict):
            continue
        before = len(entry.get("hooks", []))
        entry["hooks"] = [h for h in entry.get("hooks", []) if not is_ours(h)]
        removed += before - len(entry["hooks"])
        if not entry["hooks"]:
            pre.remove(entry)
    if not pre:
        hooks.pop("PreToolUse", None)
    if not hooks:
        data.pop("hooks", None)
    print("  removed %d hook entr%s" % (removed, "y" if removed == 1 else "ies"))

if json.dumps(data, sort_keys=True) != original:
    if os.path.exists(settings_path):
        shutil.copyfile(settings_path, settings_path + ".bak")
        print("  backup       %s.bak" % settings_path)
    with open(settings_path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
        fh.write("\n")
    print("  wrote        %s" % settings_path)
else:
    print("  settings.json unchanged")
PYEOF
}

if [[ $UNINSTALL -eq 1 ]]; then
  log "Uninstalling Claude Code Guardrails from ${CLAUDE_DIR}"
  for f in hooks/guard-destructive.py hooks/guard-secrets.py \
           skills/changelog/SKILL.md skills/changelog/scripts/changelog.py \
           agents/pr-reviewer.md; do
    if [[ -e "${CLAUDE_DIR}/${f}" ]]; then run rm -f "${CLAUDE_DIR}/${f}"; [[ $DRY_RUN -eq 1 ]] || log "  removed ${CLAUDE_DIR}/${f}"; fi
  done
  for d in skills/changelog/scripts skills/changelog; do
    [[ -d "${CLAUDE_DIR}/${d}" ]] && [[ -z "$(ls -A "${CLAUDE_DIR}/${d}" 2>/dev/null)" ]] && run rmdir "${CLAUDE_DIR}/${d}" || true
  done
  merge_settings uninstall
  log "Left in place: ${CLAUDE_DIR}/guardrails.json (delete it yourself if unwanted)."
  exit 0
fi

log "Installing Claude Code Guardrails into ${CLAUDE_DIR}"
copy_file "${PACK_DIR}/hooks/guard-destructive.py"            "${CLAUDE_DIR}/hooks/guard-destructive.py"
copy_file "${PACK_DIR}/hooks/guard-secrets.py"                "${CLAUDE_DIR}/hooks/guard-secrets.py"
copy_file "${PACK_DIR}/skills/changelog/SKILL.md"             "${CLAUDE_DIR}/skills/changelog/SKILL.md"
copy_file "${PACK_DIR}/skills/changelog/scripts/changelog.py" "${CLAUDE_DIR}/skills/changelog/scripts/changelog.py"
copy_file "${PACK_DIR}/agents/pr-reviewer.md"                 "${CLAUDE_DIR}/agents/pr-reviewer.md"
run chmod +x "${CLAUDE_DIR}/hooks/guard-destructive.py" "${CLAUDE_DIR}/hooks/guard-secrets.py" \
             "${CLAUDE_DIR}/skills/changelog/scripts/changelog.py" 2>/dev/null || true

if [[ $NO_CONFIG -eq 0 ]]; then
  if [[ -e "${CLAUDE_DIR}/guardrails.json" && $FORCE -eq 0 ]]; then
    log "  kept existing ${CLAUDE_DIR}/guardrails.json (use --force to overwrite)"
  else
    copy_file "${PACK_DIR}/guardrails.example.json" "${CLAUDE_DIR}/guardrails.json"
  fi
fi

if [[ $NO_TEMPLATE -eq 0 && $GLOBAL -eq 0 ]]; then
  dst="${TARGET}/CLAUDE.md.nextjs-sqlite.template"
  if [[ -e "$dst" && $FORCE -eq 0 ]]; then
    log "  kept existing ${dst}"
  else
    copy_file "${PACK_DIR}/templates/CLAUDE.md.nextjs-sqlite" "$dst"
    log "  (rename to CLAUDE.md and fill in the placeholders if this is a Next.js + SQLite project)"
  fi
fi

log "Merging hook entries into ${SETTINGS}"
merge_settings install

log ""
log "Done. Verify with:"
log "  echo '{\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"rm -rf /\"}}' | python3 ${CLAUDE_DIR}/hooks/guard-destructive.py; echo exit=\$?"
log "Expected: a BLOCKED message and exit=2. Restart Claude Code (or run /hooks) to load the hooks."
