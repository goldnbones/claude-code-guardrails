#!/usr/bin/env python3
"""
changelog.py -- generate a Keep-a-Changelog section from git history.

Reads conventional commits (feat, fix, perf, docs, refactor, ...) between a
base ref (default: the most recent tag) and a head ref (default: HEAD) and
renders a Markdown section such as:

    ## [1.4.0] - 2026-09-14

    ### Breaking Changes
    - **api:** rename `createUser` to `users.create` (a1b2c3d)

    ### Added
    - **auth:** magic-link sign in (d4e5f6a)

    ### Fixed
    - handle empty SQLite result sets (9f8e7d6)

Usage:
    changelog.py                          # print "Unreleased" section since last tag
    changelog.py --version 1.4.0 --write  # insert/replace section in CHANGELOG.md
    changelog.py --since v1.3.0 --until HEAD --include-all
    changelog.py --format json            # machine-readable output

Options:
    --repo PATH        git repository (default: current directory)
    --since REF        base ref (default: latest tag reachable from --until;
                       entire history if there are no tags)
    --until REF        head ref (default: HEAD)
    --version NAME     section title (default: "Unreleased")
    --date YYYY-MM-DD  section date (default: today, omitted for Unreleased)
    --write            update CHANGELOG.md in the repo (creates it if missing)
    --output PATH      changelog file to update (default: <repo>/CHANGELOG.md)
    --repo-url URL     base URL for commit links (auto-detected from origin)
    --no-links         do not link commit hashes
    --include-all      include non-conventional and chore/ci/build/test commits
    --include-merges   include merge commits
    --format FMT       markdown (default) or json
    --tag-pattern GLOB only consider tags matching this glob (e.g. "v*")

Dependency-free: Python 3.8+ standard library only. Exit code 0 on success,
1 on usage errors, 2 if git is unavailable / not a repository.
"""

import argparse
import datetime
import json
import os
import re
import subprocess
import sys

CONVENTIONAL_RE = re.compile(
    r"^(?P<type>[A-Za-z]+)(?:\((?P<scope>[^)]*)\))?(?P<bang>!)?:\s*(?P<desc>.+)$")
BREAKING_BODY_RE = re.compile(r"^BREAKING[ -]CHANGE:\s*(?P<text>.+)$", re.M)
ISSUE_REF_RE = re.compile(r"\(?(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)?\s*#(\d+)\)?", re.I)

# Conventional type -> Keep-a-Changelog section. Order defines output order.
SECTIONS = [
    ("breaking", "Breaking Changes"),
    ("feat", "Added"),
    ("change", "Changed"),
    ("deprecate", "Deprecated"),
    ("remove", "Removed"),
    ("fix", "Fixed"),
    ("security", "Security"),
    ("perf", "Performance"),
    ("docs", "Documentation"),
    ("revert", "Reverted"),
    ("other", "Other"),
]
TYPE_TO_SECTION = {
    "feat": "feat", "feature": "feat", "add": "feat",
    "fix": "fix", "bugfix": "fix", "hotfix": "fix",
    "perf": "perf", "performance": "perf",
    "docs": "docs", "doc": "docs",
    "refactor": "change", "style": "change", "change": "change", "update": "change", "improve": "change",
    "deprecate": "deprecate", "deprecated": "deprecate",
    "remove": "remove", "removed": "remove", "delete": "remove",
    "security": "security", "sec": "security",
    "revert": "revert",
    "build": "other", "ci": "other", "chore": "other", "test": "other", "tests": "other",
}

CHANGELOG_PREAMBLE = """# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
"""


class GitError(Exception):
    pass


def git(repo, *args):
    try:
        res = subprocess.run(["git", "-C", repo] + list(args), capture_output=True, text=True)
    except OSError as exc:
        raise GitError("git is not available: %s" % exc)
    if res.returncode != 0:
        raise GitError((res.stderr or res.stdout).strip() or "git %s failed" % " ".join(args))
    return res.stdout


def latest_tag(repo, until, tag_pattern=None):
    args = ["describe", "--tags", "--abbrev=0"]
    if tag_pattern:
        args += ["--match", tag_pattern]
    args.append(until)
    try:
        return git(repo, *args).strip() or None
    except GitError:
        return None


def detect_repo_url(repo):
    """Turn an origin remote into a browsable https URL, or None."""
    try:
        remote = git(repo, "remote", "get-url", "origin").strip()
    except GitError:
        return None
    m = re.match(r"^(?:git@|ssh://git@|https?://)([^/:]+)[:/](.+?)(?:\.git)?/?$", remote)
    if not m:
        return None
    host, path = m.group(1), m.group(2)
    return "https://%s/%s" % (host, path)


def commit_url(repo_url, sha):
    if not repo_url:
        return None
    if "gitlab" in repo_url:
        return "%s/-/commit/%s" % (repo_url, sha)
    if "bitbucket" in repo_url:
        return "%s/commits/%s" % (repo_url, sha)
    return "%s/commit/%s" % (repo_url, sha)


def read_commits(repo, since, until, include_merges):
    rev_range = "%s..%s" % (since, until) if since else until
    args = ["log", "--format=%H%x1f%h%x1f%s%x1f%b%x1e", "--reverse"]
    if not include_merges:
        args.append("--no-merges")
    args.append(rev_range)
    out = git(repo, *args)
    commits = []
    for record in out.split("\x1e"):
        record = record.strip("\n")
        if not record.strip():
            continue
        parts = record.split("\x1f")
        if len(parts) < 3:
            continue
        sha, short, subject = parts[0].strip(), parts[1].strip(), parts[2].strip()
        body = parts[3].strip() if len(parts) > 3 else ""
        commits.append({"sha": sha, "short": short, "subject": subject, "body": body})
    return commits


def parse_commit(commit):
    """Classify a commit; returns dict with section, scope, description, breaking."""
    subject, body = commit["subject"], commit["body"]
    m = CONVENTIONAL_RE.match(subject)
    breaking_notes = [b.group("text").strip() for b in BREAKING_BODY_RE.finditer(body)]
    entry = {
        "sha": commit["sha"], "short": commit["short"],
        "type": None, "scope": None, "description": subject,
        "section": "other", "conventional": False,
        "breaking": bool(breaking_notes), "breaking_notes": breaking_notes,
        "issues": [],
    }
    if m:
        ctype = m.group("type").lower()
        entry.update(type=ctype, scope=(m.group("scope") or "").strip() or None,
                     description=m.group("desc").strip(), conventional=True,
                     section=TYPE_TO_SECTION.get(ctype, "other"))
        if m.group("bang"):
            entry["breaking"] = True
        if ctype == "fix" and entry["scope"] and entry["scope"].lower() in ("security", "sec"):
            entry["section"] = "security"
    entry["issues"] = sorted({n for n in ISSUE_REF_RE.findall(subject + "\n" + body)}, key=int)
    if entry["breaking"]:
        entry["section"] = "breaking"
    return entry


def build_sections(commits, include_all):
    grouped = {key: [] for key, _ in SECTIONS}
    for c in commits:
        e = parse_commit(c)
        if e["section"] == "other" and not include_all:
            continue
        grouped[e["section"]].append(e)
    return grouped


def render_entry(e, repo_url, links):
    desc = e["description"]
    desc = desc[0].upper() + desc[1:] if desc and desc[0].islower() else desc
    desc = desc.rstrip(".")
    line = "- "
    section_name = dict(SECTIONS).get(e["section"], "").lower()
    if e["scope"] and e["scope"].lower() not in (section_name, e["section"]):
        line += "**%s:** " % e["scope"]
    line += desc
    if e["section"] == "breaking" and e["breaking_notes"]:
        line += " -- " + "; ".join(e["breaking_notes"])
    missing_issues = [n for n in e["issues"] if "#%s" % n not in desc]
    if missing_issues:
        line += " (" + ", ".join("#%s" % n for n in missing_issues) + ")"
    if links:
        url = commit_url(repo_url, e["sha"])
        line += " ([%s](%s))" % (e["short"], url) if url else " (%s)" % e["short"]
    return line


def render_markdown(grouped, version, date, repo_url, links, since, until):
    title = "## [%s]" % version
    if date:
        title += " - %s" % date
    lines = [title, ""]
    total = 0
    for key, heading in SECTIONS:
        entries = grouped.get(key) or []
        if not entries:
            continue
        total += len(entries)
        lines.append("### %s" % heading)
        lines.append("")
        for e in entries:
            lines.append(render_entry(e, repo_url, links))
        lines.append("")
    if total == 0:
        lines.append("_No notable changes%s._" % (" since %s" % since if since else ""))
        lines.append("")
    if repo_url and since and links:
        lines.append("[%s]: %s/compare/%s...%s" % (version, repo_url, since, until if version == "Unreleased" else version))
        lines.append("")
    return "\n".join(lines).rstrip("\n") + "\n"


def render_json(grouped, version, date, since, until):
    return json.dumps({
        "version": version, "date": date, "since": since, "until": until,
        "sections": {heading: grouped.get(key, []) for key, heading in SECTIONS if grouped.get(key)},
    }, indent=2)


def upsert_section(existing, section_md, version):
    """Insert section_md into an existing changelog, replacing any section
    with the same version. Sections start with '## '."""
    if not existing.strip():
        return CHANGELOG_PREAMBLE + "\n" + section_md
    lines = existing.split("\n")
    header_re = re.compile(r"^## \[?%s\]?(?:\s|$)" % re.escape(version))
    # Locate existing section for this version.
    start = end = None
    for i, line in enumerate(lines):
        if start is None and header_re.match(line):
            start = i
            continue
        if start is not None and line.startswith("## "):
            end = i
            break
    if start is not None:
        if end is None:
            # Section runs to end of file, but keep trailing link references.
            end = len(lines)
            for j in range(start + 1, len(lines)):
                if re.match(r"^\[[^\]]+\]:\s*\S+", lines[j]):
                    end = j
                    break
        new_lines = lines[:start] + section_md.rstrip("\n").split("\n") + [""] + lines[end:]
        return "\n".join(new_lines).rstrip("\n") + "\n"
    # Insert before the first existing section, or append after preamble.
    for i, line in enumerate(lines):
        if line.startswith("## "):
            new_lines = lines[:i] + section_md.rstrip("\n").split("\n") + [""] + lines[i:]
            return "\n".join(new_lines).rstrip("\n") + "\n"
    return existing.rstrip("\n") + "\n\n" + section_md


def main(argv=None):
    parser = argparse.ArgumentParser(description="Generate a Keep-a-Changelog section from conventional commits.")
    parser.add_argument("--repo", default=".")
    parser.add_argument("--since")
    parser.add_argument("--until", default="HEAD")
    parser.add_argument("--version", default="Unreleased")
    parser.add_argument("--date")
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--output")
    parser.add_argument("--repo-url")
    parser.add_argument("--no-links", action="store_true")
    parser.add_argument("--include-all", action="store_true")
    parser.add_argument("--include-merges", action="store_true")
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    parser.add_argument("--tag-pattern")
    args = parser.parse_args(argv)

    repo = os.path.abspath(args.repo)
    try:
        git(repo, "rev-parse", "--is-inside-work-tree")
        since = args.since or latest_tag(repo, args.until, args.tag_pattern)
        # A tag that points at --until yields an empty range; that's fine.
        commits = read_commits(repo, since, args.until, args.include_merges)
    except GitError as exc:
        sys.stderr.write("changelog: %s\n" % exc)
        return 2

    grouped = build_sections(commits, args.include_all)
    date = args.date
    if date is None and args.version.lower() != "unreleased":
        date = datetime.date.today().isoformat()
    repo_url = args.repo_url or detect_repo_url(repo)
    links = not args.no_links

    if args.format == "json":
        sys.stdout.write(render_json(grouped, args.version, date, since, args.until) + "\n")
        return 0

    section = render_markdown(grouped, args.version, date, repo_url, links, since, args.until)
    if not args.write:
        sys.stdout.write(section)
        return 0

    path = args.output or os.path.join(repo, "CHANGELOG.md")
    existing = ""
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            existing = fh.read()
    updated = upsert_section(existing, section, args.version)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(updated)
    count = sum(len(v) for v in grouped.values())
    sys.stdout.write("changelog: wrote %d entries for [%s] to %s\n" % (count, args.version, path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
