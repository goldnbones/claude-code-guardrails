---
name: changelog
description: Generate or update a Keep-a-Changelog style CHANGELOG.md section from conventional commits (feat/fix/perf/docs/refactor/breaking) since the last git tag. Use when the user asks to "write the changelog", "prepare release notes", "cut a release", or "what changed since the last version".
---

# Changelog generator

This skill turns the git history since the last tag into a Keep-a-Changelog
section, grouped by conventional-commit type:

| Commit type                          | Section            |
|--------------------------------------|--------------------|
| `feat`                               | Added              |
| `refactor`, `style`, `change`        | Changed            |
| `deprecate`                          | Deprecated         |
| `remove`                             | Removed            |
| `fix`                                | Fixed              |
| `security`, `fix(security)`          | Security           |
| `perf`                               | Performance        |
| `docs`                               | Documentation      |
| `revert`                             | Reverted           |
| `!` suffix or `BREAKING CHANGE:` body| Breaking Changes   |
| `chore`, `ci`, `build`, `test`, non-conventional | Other (only with `--include-all`) |

The script lives at `scripts/changelog.py` relative to this file (installed
as `.claude/skills/changelog/scripts/changelog.py`). It needs only Python 3
and git.

## Procedure

1. Preview the section for the pending release (defaults to everything since
   the most recent tag, titled "Unreleased"):

   ```bash
   python3 .claude/skills/changelog/scripts/changelog.py
   ```

2. Read the output critically. Fix commit messages that are unclear *only if
   the user asks*; otherwise edit the wording in the generated Markdown.

3. When the user names a version, write it into `CHANGELOG.md`. The script
   inserts the section above older sections and replaces an existing section
   with the same version, so re-running is safe:

   ```bash
   python3 .claude/skills/changelog/scripts/changelog.py --version 1.4.0 --write
   ```

4. Show the user the resulting section and offer the follow-up commands they
   usually want next (do not run them unprompted):

   ```bash
   git add CHANGELOG.md && git commit -m "docs(changelog): release 1.4.0"
   git tag -a v1.4.0 -m "v1.4.0"
   ```

## Useful flags

| Flag                | Effect                                                     |
|---------------------|------------------------------------------------------------|
| `--since v1.2.0`    | Base ref (default: latest tag; whole history if no tags)   |
| `--until HEAD~2`    | Head ref                                                   |
| `--include-all`     | Also list chore/ci/build/test and non-conventional commits |
| `--include-merges`  | Include merge commits                                      |
| `--no-links`        | Plain short hashes instead of commit links                 |
| `--repo-url URL`    | Override the auto-detected GitHub/GitLab/Bitbucket URL     |
| `--tag-pattern v*`  | Only treat tags matching the glob as releases              |
| `--format json`     | Structured output for release tooling                      |
| `--output PATH`     | Write to a file other than `<repo>/CHANGELOG.md`           |

## Notes

- Issue references like `#42`, `closes #42` in subject or body are appended
  to the entry.
- Descriptions are capitalised and trailing periods removed for consistency.
- If there are no notable commits, the section says so instead of being
  empty -- tell the user rather than inventing entries.
- The script never commits, tags, or pushes.
